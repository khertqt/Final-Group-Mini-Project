<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <title>EduFlow Hub - Settings</title>
  <link rel="stylesheet" href="globals.css" />
  <link rel="stylesheet" href="settings.css" />
</head>
<body>
  <div class="settings">
    <nav class="top-navbar">
      <div class="navbar-container">
        <div class="brand">
          <div class="brand-logo">
            <div class="logo-icon"></div>
          </div>
          <div class="brand-text">
            <h1 class="brand-title">EduFlow Hub</h1>
            <p class="brand-subtitle">Smart Learning Flow</p>
          </div>
        </div>

        <button class="mobile-menu-toggle" aria-label="Toggle menu">
          <span></span>
          <span></span>
          <span></span>
        </button>

        <div class="nav-links">
          <a href="dashboard.php" class="nav-link">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/icon.svg" alt="" />
            <span>Dashboard</span>
          </a>
          <a href="classes.php" class="nav-link">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/icon-4.svg" alt="" />
            <span>Classes</span>
          </a>
          <a href="ass.php" class="nav-link">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/icon-6.svg" alt="" />
            <span>Assignments</span>
          </a>
          <a href="study.php" class="nav-link">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/icon-3.svg" alt="" />
            <span>Study Planner</span>
          </a>
          <a href="mess.php" class="nav-link">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/icon-1.svg" alt="" />
            <span>Messages</span>
          </a>
          <a href="notif.php" class="nav-link">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/icon-5.svg" alt="" />
            <span>Notifications</span>
            <span class="badge">3</span>
          </a>
        </div>

        <div class="user-section">
          <a href="settings.html" class="notification-btn" aria-label="Settings">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/button.svg" alt="" />
          </a>
          <a href="profile.php" class="user-profile">
            <div class="user-avatar">
              <span>KG</span>
            </div>
            <div class="user-info">
              <p class="user-name">Khert Galarde</p>
              <p class="user-role">Student</p>
            </div>
          </a>
        </div>
      </div>
    </nav>

    <main class="main-content">
      <header class="page-header">
        <h1>Settings</h1>
        <p>Manage your account preferences and settings.</p>
      </header>

      <div class="settings-card">
        <div class="tabs">
          <button class="tab active" data-tab="account">Account</button>
          <button class="tab" data-tab="notifications">Notifications</button>
          <button class="tab" data-tab="privacy">Privacy</button>
          <button class="tab" data-tab="help">Help</button>
        </div>

        <div class="tab-content active" id="account">
          <div class="section-header">
            <img src="https://c.animaapp.com/milablqn3suJmf/img/icon-2.svg" alt="" />
            <h2>Account Settings</h2>
          </div>

          <div class="card">
            <div class="card-header">
              <h3>Change Email</h3>
              <p>Update your email address</p>
            </div>
            <form class="card-content" id="emailForm">
              <div class="form-group">
                <label for="currentEmail">Current Email</label>
                <input 
                  type="email" 
                  id="currentEmail" 
                  value="s.gallarde.khertbrianne@cmu.edu.ph"
                  disabled
                />
              </div>
              <div class="form-group">
                <label for="newEmail">New Email</label>
                <input 
                  type="email" 
                  id="newEmail" 
                  placeholder="Enter new email"
                  required
                />
              </div>
              <button type="submit" class="btn-primary">Update Email</button>
              <div class="form-message" id="emailMessage"></div>
            </form>
          </div>

          <div class="card">
            <div class="card-header">
              <h3>Change Password</h3>
              <p>Update your password regularly for security</p>
            </div>
            <form class="card-content" id="passwordForm">
              <div class="form-group">
                <label for="currentPassword">Current Password</label>
                <input 
                  type="password" 
                  id="currentPassword" 
                  placeholder="Enter current password"
                  required
                />
              </div>
              <div class="form-group">
                <label for="newPassword">New Password</label>
                <input 
                  type="password" 
                  id="newPassword" 
                  placeholder="Enter new password"
                  required
                  minlength="8"
                />
              </div>
              <div class="form-group">
                <label for="confirmPassword">Confirm New Password</label>
                <input 
                  type="password" 
                  id="confirmPassword" 
                  placeholder="Confirm new password"
                  required
                />
              </div>
              <button type="submit" class="btn-primary">Change Password</button>
              <div class="form-message" id="passwordMessage"></div>
            </form>
          </div>

          <div class="card">
            <div class="card-header">
              <h3>Linked Accounts</h3>
              <p>Manage connected services</p>
            </div>
            <div class="card-content">
              <div class="linked-account">
                <div class="account-info">
                  <p class="account-name">Google Account</p>
                  <p class="account-email">gallardekhert@gmail.com</p>
                </div>
                <button class="btn-secondary" onclick="disconnectAccount('google')">Disconnect</button>
              </div>
              <div class="linked-account">
                <div class="account-info">
                  <p class="account-name">Microsoft Account</p>
                  <p class="account-status">Not connected</p>
                </div>
                <button class="btn-secondary" onclick="connectAccount('microsoft')">Connect</button>
              </div>
            </div>
          </div>
        </div>

        <div class="tab-content" id="notifications">
          <div class="section-header">
            <h2>Notification Settings</h2>
          </div>
          <div class="card">
            <div class="card-content">
              <p>Notification settings coming soon...</p>
            </div>
          </div>
        </div>

        <div class="tab-content" id="privacy">
          <div class="section-header">
            <h2>Privacy Settings</h2>
          </div>
          <div class="card">
            <div class="card-content">
              <p>Privacy settings coming soon...</p>
            </div>
          </div>
        </div>

        <div class="tab-content" id="help">
          <div class="section-header">
            <h2>Help & Support</h2>
          </div>
          <div class="card">
            <div class="card-content">
              <p>Help resources coming soon...</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>

  <script src="settings.js"></script>
</body>
</html>
