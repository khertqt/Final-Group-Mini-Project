// Modal functionality
const modal = document.getElementById('editModal');
const editButtons = document.querySelectorAll('.edit-profile-btn, .action-btn:first-child');
const closeBtn = document.querySelector('.close-btn');
const cancelBtn = document.querySelector('.cancel-btn');
const form = document.querySelector('.modal-body');

// Open modal
editButtons.forEach(button => {
  button.addEventListener('click', () => {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  });
});

// Close modal
function closeModal() {
  modal.classList.remove('active');
  document.body.style.overflow = 'auto';
}

closeBtn.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);

// Close modal when clicking outside
modal.addEventListener('click', (e) => {
  if (e.target === modal) {
    closeModal();
  }
});

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && modal.classList.contains('active')) {
    closeModal();
  }
});

// Form submission
form.addEventListener('submit', (e) => {
  e.preventDefault();
  
  // Get form values
  const formData = new FormData(form);
  const inputs = form.querySelectorAll('input');
  
  // Simulate saving (in real app, this would be an API call)
  console.log('Saving profile changes...');
  
  // Show success message
  alert('Profile updated successfully!');
  
  // Close modal
  closeModal();
});

// Navigation buttons functionality
const navButtons = document.querySelectorAll('.nav-button');
navButtons.forEach(button => {
  button.addEventListener('click', () => {
    const buttonText = button.querySelector('span').textContent;
    console.log(`Navigating to: ${buttonText}`);
    // In a real app, this would navigate to different pages
  });
});

// Quick action buttons
const actionButtons = document.querySelectorAll('.action-btn');
actionButtons.forEach((button, index) => {
  if (index === 0) return; // Skip Edit Profile button (already handled)
  
  button.addEventListener('click', () => {
    const action = button.textContent.trim();
    
    switch(action) {
      case 'Change Password':
        alert('Change Password functionality would open here');
        break;
      case 'View Academic Records':
        alert('Academic Records would be displayed here');
        break;
      case 'Log Out':
        if (confirm('Are you sure you want to log out?')) {
          alert('Logging out...');
          // In real app: window.location.href = '/logout';
        }
        break;
    }
  });
});

// User profile button
const userProfileBtn = document.querySelector('.user-profile-btn');
userProfileBtn.addEventListener('click', () => {
  console.log('User profile menu would open here');
  // In real app, this could show a dropdown menu
});

// Notification button
const notificationBtn = document.querySelector('.notification-btn');
notificationBtn.addEventListener('click', () => {
  console.log('Notifications panel would open here');
  // In real app, this would show notifications
});

// Add active state to current nav item
const currentPage = 'Profile'; // This would be dynamic in a real app
navButtons.forEach(button => {
  const buttonText = button.querySelector('span').textContent;
  if (buttonText === currentPage) {
    button.style.backgroundColor = '#f3f4f6';
  }
});

// Smooth scroll behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Add loading state to buttons
function addLoadingState(button) {
  const originalText = button.textContent;
  button.disabled = true;
  button.textContent = 'Loading...';
  
  setTimeout(() => {
    button.disabled = false;
    button.textContent = originalText;
  }, 1000);
}

// Console welcome message
console.log('%cEduFlow Hub', 'font-size: 24px; font-weight: bold; color: #462fb1;');
console.log('%cProfile page loaded successfully!', 'font-size: 14px; color: #697282;');
