<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <title>EduFlow Hub - Profile</title>
  <link rel="stylesheet" href="globals.css" />
  <link rel="stylesheet" href="profile.css" />
</head>
<body>
  <div class="app">
    <!-- Sticky Top Navbar -->
    <nav class="top-navbar">
      <div class="navbar-container">
        <div class="navbar-brand">
          <div class="logo-wrapper">
            <div class="logo"></div>
          </div>
          <div class="brand-text">
            <h1 class="brand-title">EduFlow Hub</h1>
            <p class="brand-subtitle">Smart Learning Flow</p>
          </div>
        </div>

        <div class="navbar-menu">
          <a href="dashboard.php" class="nav-button">
            <img class="nav-icon" src="https://c.animaapp.com/milakdkzocDSeV/img/icon-3.svg" alt="Dashboard" />
            <span>Dashboard</span>
          </a>
          <a href="classes.php" class="nav-button">
            <img class="nav-icon" src="https://c.animaapp.com/milakdkzocDSeV/img/icon-2.svg" alt="Classes" />
            <span>Classes</span>
          </a>
          <a href="ass.php" class="nav-button">
            <img class="nav-icon" src="https://c.animaapp.com/milakdkzocDSeV/img/icon-6.svg" alt="Assignments" />
            <span>Assignments</span>
          </a>
          <a href="study.php" class="nav-button">
            <img class="nav-icon" src="https://c.animaapp.com/milakdkzocDSeV/img/icon-5.svg" alt="Study Planner" />
            <span>Study Planner</span>
          </a>
          <a href="mess.php" class="nav-button">
            <img class="nav-icon" src="https://c.animaapp.com/milakdkzocDSeV/img/icon-1.svg" alt="Messages" />
            <span>Messages</span>
          </a>
          <a href="notif.php" class="nav-button">
            <img class="nav-icon" src="https://c.animaapp.com/milakdkzocDSeV/img/icon.svg" alt="Notifications" />
            <span>Notifications</span>
            <span class="badge">3</span>
          </a>
        </div>

        <div class="navbar-user">
          <a href="settings.php" class="notification-btn">
            <img src="https://c.animaapp.com/milakdkzocDSeV/img/button.svg" alt="Notifications" />
          </a>
          <a href="profile.php" class="user-profile-btn">
            <div class="user-avatar">
              <span>KG</span>
            </div>
            <div class="user-info">
              <p class="user-name">Khert Galarde</p>
              <p class="user-role">Student</p>
            </div>
          </a>
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
      <div class="content-container">
        <!-- Page Header -->
        <header class="page-header">
          <h2 class="page-title">Profile</h2>
          <p class="page-description">Manage your personal information and academic records.</p>
        </header>

        <!-- Profile Cards Grid -->
        <div class="profile-grid">
          <!-- Profile Card -->
          <div class="card profile-card">
            <img class="profile-avatar" src="https://c.animaapp.com/milakdkzocDSeV/img/container-2.svg" alt="Profile" />
            <h3 class="profile-name">Khert Galarde</h3>
            <p class="profile-title">BSIT Student</p>
            <span class="status-badge">Active</span>
            <button class="btn btn-primary edit-profile-btn">
              <img src="https://c.animaapp.com/milakdkzocDSeV/img/icon-4.svg" alt="Edit" />
              Edit Profile
            </button>
          </div>

          <!-- Profile Information Card -->
          <div class="card info-card">
            <div class="card-header">
              <h3 class="card-title">Profile Information</h3>
              <p class="card-subtitle">Your personal and academic details</p>
            </div>
            <div class="info-grid">
              <div class="info-item">
                <img src="https://c.animaapp.com/milakdkzocDSeV/img/container-4.svg" alt="Name" />
                <div class="info-content">
                  <p class="info-label">Full Name</p>
                  <p class="info-value">Khert Galarde</p>
                </div>
              </div>
              <div class="info-item">
                <img src="https://c.animaapp.com/milakdkzocDSeV/img/container-3.svg" alt="ID" />
                <div class="info-content">
                  <p class="info-label">Student ID</p>
                  <p class="info-value">2023303810</p>
                </div>
              </div>
              <div class="info-item">
                <img src="https://c.animaapp.com/milakdkzocDSeV/img/container-6.svg" alt="Program" />
                <div class="info-content">
                  <p class="info-label">Program</p>
                  <p class="info-value">BS Information Technology</p>
                </div>
              </div>
              <div class="info-item">
                <img src="https://c.animaapp.com/milakdkzocDSeV/img/container-1.svg" alt="Year" />
                <div class="info-content">
                  <p class="info-label">Year Level</p>
                  <p class="info-value">2nd Year</p>
                </div>
              </div>
              <div class="info-item">
                <img src="https://c.animaapp.com/milakdkzocDSeV/img/container.svg" alt="Email" />
                <div class="info-content">
                  <p class="info-label">Email Address</p>
                  <p class="info-value">s.gallarde.khertbrianne@cmu.edu.ph</p>
                </div>
              </div>
              <div class="info-item">
                <img src="https://c.animaapp.com/milakdkzocDSeV/img/container-5.svg" alt="Phone" />
                <div class="info-content">
                  <p class="info-label">Contact Number</p>
                  <p class="info-value">+63 975 6861 301</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Academic Overview Card -->
        <div class="card academic-card">
          <div class="card-header">
            <h3 class="card-title">Academic Overview</h3>
            <p class="card-subtitle">Your academic performance summary</p>
          </div>
          <div class="stats-grid">
            <div class="stat-item stat-blue">
              <p class="stat-label">Current GPA</p>
              <p class="stat-value">1.75</p>
            </div>
            <div class="stat-item stat-green">
              <p class="stat-label">Units Completed</p>
              <p class="stat-value">46</p>
            </div>
            <div class="stat-item stat-purple">
              <p class="stat-label">Current Semester</p>
              <p class="stat-value">1st Sem</p>
            </div>
            <div class="stat-item stat-orange">
              <p class="stat-label">Academic Year</p>
              <p class="stat-value">2025-26</p>
            </div>
          </div>
        </div>

        <!-- Quick Actions Card -->
        <div class="card actions-card">
          <h3 class="card-title">Quick Actions</h3>
          <div class="actions-grid">
            <button class="btn btn-primary action-btn">Edit Profile</button>
            <button class="btn btn-secondary action-btn">Change Password</button>
            <button class="btn btn-secondary action-btn">View Academic Records</button>
            <a button class="btn btn-secondary action-btn" href= "login.php" >Log Out</a>
          </div>
        </div>
      </div>
    </main>
  </div>

  <!-- Edit Profile Modal -->
  <div id="editModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Edit Profile</h3>
        <button class="close-btn">&times;</button>
      </div>
      <form class="modal-body">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" value="Khert Galarde" />
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" value="s.gallarde.khertbrianne@cmu.edu.ph" />
        </div>
        <div class="form-group">
          <label>Contact Number</label>
          <input type="tel" value="+63 975 6861 301" />
        </div>
        <div class="form-group">
          <label>Program</label>
          <input type="text" value="BS Information Technology" />
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary cancel-btn">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
      </form>
    </div>
  </div>

  <script src="profile.js"></script>
</body>
</html>
