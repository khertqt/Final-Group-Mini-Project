<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <title>EduFlow Hub - Assignments</title>
  <link rel="stylesheet" href="globals.css" />
  <link rel="stylesheet" href="ass.css" />
</head>
<body>
  <div class="app">
    <!-- Sticky Top Navbar -->
    <nav class="top-navbar">
      <div class="navbar-container">
        <div class="navbar-brand">
          <div class="logo-wrapper">
            <div class="logo-icon"></div>
          </div>
          <div class="brand-text">
            <h1 class="brand-name">EduFlow Hub</h1>
            <p class="brand-tagline">Smart Learning Flow</p>
          </div>
        </div>

        <div class="navbar-menu">
        <a class="nav-button" href="dashboard.php">
          <img class="nav-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-21.svg" alt="Dashboard" />
          <span>Dashboard</span>
        </a>

        <a class="nav-button" href="classes.php">
          <img class="nav-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-18.svg" alt="Classes" />
          <span>Classes</span>
        </a>

        <a class="nav-button active" href="ass.php">
          <img class="nav-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-14.svg" alt="Assignments" />
          <span>Assignments</span>
        </a>

        <a class="nav-button" href="study.php">
          <img class="nav-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-24.svg" alt="Study Planner" />
          <span>Study Planner</span>
        </a>

        <a class="nav-button" href="mess.php">
          <img class="nav-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-15.svg" alt="Messages" />
          <span>Messages</span>
        </a>

        <a class="nav-button" href="notif.php">
          <img class="nav-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-25.svg" alt="Notifications" />
          <span>Notifications</span>
          <span class="notification-badge">3</span>
        </a>
      </div>

      <div class="navbar-user">
        <a class="search-button" href="settings.php">
          <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/button.svg" alt="Search" />
        </a>

        <a class="user-profile" href="profile.php">
          <div class="user-avatar">KG</div>
          <div class="user-info">
            <span class="user-name">Khert Galarde</span>
            <span class="user-role">Student</span>
          </div>
        </a>
      </div>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
      <div class="content-container">
        <!-- Page Header -->
        <header class="page-header">
          <h2 class="page-title">Assignments</h2>
          <p class="page-description">Track and submit your assignments.</p>
        </header>

        <!-- Stats Cards -->
        <div class="stats-grid">
          <div class="stat-card stat-ongoing">
            <img class="stat-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-6.svg" alt="Ongoing" />
            <div class="stat-content">
              <div class="stat-number">2</div>
              <div class="stat-label">Ongoing</div>
            </div>
          </div>
          <div class="stat-card stat-upcoming">
            <img class="stat-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-7.svg" alt="Upcoming" />
            <div class="stat-content">
              <div class="stat-number">3</div>
              <div class="stat-label">Upcoming</div>
            </div>
          </div>
          <div class="stat-card stat-completed">
            <img class="stat-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-8.svg" alt="Completed" />
            <div class="stat-content">
              <div class="stat-number">2</div>
              <div class="stat-label">Completed</div>
            </div>
          </div>
          <div class="stat-card stat-overdue">
            <img class="stat-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-11.svg" alt="Overdue" />
            <div class="stat-content">
              <div class="stat-number">1</div>
              <div class="stat-label">Overdue</div>
            </div>
          </div>
        </div>

        <!-- Assignments List -->
        <div class="assignments-section">
          <div class="section-header">
            <h3 class="section-title">All Assignments</h3>
            <p class="section-description">View assignments by status</p>
          </div>

          <!-- Filter Tabs -->
          <div class="filter-tabs">
            <button class="tab-button active">All</button>
            <button class="tab-button">Ongoing</button>
            <button class="tab-button">Upcoming</button>
            <button class="tab-button">Completed</button>
            <button class="tab-button">Overdue</button>
          </div>

          <!-- Assignment Cards -->
          <div class="assignment-list">
            <!-- Assignment 1: Ongoing -->
            <article class="assignment-card card-ongoing">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-2.svg" alt="Web Development" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Activity 1: HTML Page Design</h4>
                      <span class="status-badge badge-ongoing">Ongoing</span>
                    </div>
                    <p class="course-name">Web Development 101</p>
                  </div>
                </div>
                <div class="assignment-points">50 pts</div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">
                  Create a responsive HTML page using semantic elements. The page should include a header,
                  navigation, main content area, sidebar, and footer. Use proper HTML5 semantic tags.
                </p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Nov 25, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>11:59 PM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-primary" onclick="handleSubmit('Activity 1: HTML Page Design')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-3.svg" alt="" />
                    Submit
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Activity 1: HTML Page Design')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-1.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>

            <!-- Assignment 2: Completed -->
            <article class="assignment-card card-completed">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-1.svg" alt="Data Structures" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Quiz 2: Recursion</h4>
                      <span class="status-badge badge-completed">Completed</span>
                    </div>
                    <p class="course-name">Data Structures &amp; Algorithms</p>
                  </div>
                </div>
                <div class="assignment-points-grade">
                  <div>30 pts</div>
                  <div class="grade">Grade: 95%</div>
                </div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">Online quiz covering recursion and backtracking</p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Nov 22, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>10:00 AM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-secondary" onclick="handleViewFeedback('Quiz 2: Recursion')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon.svg" alt="" />
                    View Feedback
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Quiz 2: Recursion')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-1.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>

            <!-- Assignment 3: Upcoming -->
            <article class="assignment-card card-upcoming">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container.svg" alt="Humanities" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Research Paper Draft</h4>
                      <span class="status-badge badge-upcoming">Upcoming</span>
                    </div>
                    <p class="course-name">Humanities</p>
                  </div>
                </div>
                <div class="assignment-points">100 pts</div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">Submit first draft of research paper (min 10 pages)</p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Nov 30, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>11:59 PM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-primary" onclick="handleSubmit('Research Paper Draft')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-3.svg" alt="" />
                    Submit
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Research Paper Draft')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-1.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>

            <!-- Assignment 4: Overdue -->
            <article class="assignment-card card-overdue">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-3.svg" alt="Database Management" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Database Normalization Task</h4>
                      <span class="status-badge badge-overdue">Overdue</span>
                    </div>
                    <p class="course-name">Database Management</p>
                  </div>
                </div>
                <div class="assignment-points">40 pts</div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">Normalize given database schema to 3NF</p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Nov 18, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>5:00 PM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-danger" onclick="handleSubmitLate('Database Normalization Task')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-3.svg" alt="" />
                    Submit Late
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Database Normalization Task')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-23.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>

            <!-- Assignment 5: Upcoming -->
            <article class="assignment-card card-upcoming">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container.svg" alt="Web Development" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Project Proposal</h4>
                      <span class="status-badge badge-upcoming">Upcoming</span>
                    </div>
                    <p class="course-name">Web Development 101</p>
                  </div>
                </div>
                <div class="assignment-points">75 pts</div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">Submit proposal for final project</p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Nov 28, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>11:59 PM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-primary" onclick="handleSubmit('Project Proposal')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-3.svg" alt="" />
                    Submit
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Project Proposal')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-1.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>

            <!-- Assignment 6: Completed -->
            <article class="assignment-card card-completed">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-1.svg" alt="Web Development" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Midterm Exam</h4>
                      <span class="status-badge badge-completed">Completed</span>
                    </div>
                    <p class="course-name">Web Development 101</p>
                  </div>
                </div>
                <div class="assignment-points-grade">
                  <div>100 pts</div>
                  <div class="grade">Grade: 88%</div>
                </div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">Comprehensive exam covering topics 1-5</p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Nov 15, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>2:00 PM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-secondary" onclick="handleViewFeedback('Midterm Exam')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon.svg" alt="" />
                    View Feedback
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Midterm Exam')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-1.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>

            <!-- Assignment 7: Ongoing -->
            <article class="assignment-card card-ongoing">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container-2.svg" alt="Database Management" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Lab Exercise 3</h4>
                      <span class="status-badge badge-ongoing">Ongoing</span>
                    </div>
                    <p class="course-name">Database Management</p>
                  </div>
                </div>
                <div class="assignment-points">50 pts</div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">SQL queries and database design</p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Nov 26, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>11:59 PM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-primary" onclick="handleSubmit('Lab Exercise 3')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-3.svg" alt="" />
                    Submit
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Lab Exercise 3')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-1.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>

            <!-- Assignment 8: Upcoming -->
            <article class="assignment-card card-upcoming">
              <div class="assignment-header">
                <div class="assignment-info">
                  <img class="course-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/container.svg" alt="Humanities" />
                  <div class="assignment-meta">
                    <div class="title-row">
                      <h4 class="assignment-title">Essay: Cultural Analysis</h4>
                      <span class="status-badge badge-upcoming">Upcoming</span>
                    </div>
                    <p class="course-name">Humanities</p>
                  </div>
                </div>
                <div class="assignment-points">80 pts</div>
              </div>
              <div class="assignment-body">
                <p class="assignment-description">Write an essay analyzing cultural perspectives</p>
                <div class="assignment-meta-info">
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-7.svg" alt="Due date" />
                    <span>Due: Dec 5, 2025</span>
                  </div>
                  <div class="meta-item">
                    <img class="meta-icon" src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-4.svg" alt="Time" />
                    <span>11:59 PM</span>
                  </div>
                </div>
                <div class="assignment-actions">
                  <button class="btn btn-primary" onclick="handleSubmit('Essay: Cultural Analysis')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-3.svg" alt="" />
                    Submit
                  </button>
                  <button class="btn btn-secondary" onclick="handleViewDetails('Essay: Cultural Analysis')">
                    <img src="https://c.animaapp.com/mil8gs13hbdkNW/img/icon-1.svg" alt="" />
                    View Details
                  </button>
                </div>
              </div>
            </article>
          </div>
        </div>
      </div>
    </main>
  </div>

  <script src="ass.js"></script>
</body>
</html>
