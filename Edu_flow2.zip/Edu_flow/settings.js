// Mobile menu toggle
const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const navLinks = document.querySelector('.nav-links');

if (mobileMenuToggle) {
  mobileMenuToggle.addEventListener('click', () => {
    mobileMenuToggle.classList.toggle('active');
    navLinks.classList.toggle('active');
  });
}

// Tab switching
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const targetTab = tab.dataset.tab;
    
    // Remove active class from all tabs and contents
    tabs.forEach(t => t.classList.remove('active'));
    tabContents.forEach(content => content.classList.remove('active'));
    
    // Add active class to clicked tab and corresponding content
    tab.classList.add('active');
    document.getElementById(targetTab).classList.add('active');
  });
});

// Email form submission
const emailForm = document.getElementById('emailForm');
const emailMessage = document.getElementById('emailMessage');

emailForm.addEventListener('submit', (e) => {
  e.preventDefault();
  
  const newEmail = document.getElementById('newEmail').value;
  
  if (!newEmail) {
    showMessage(emailMessage, 'Please enter a new email address', 'error');
    return;
  }
  
  if (!isValidEmail(newEmail)) {
    showMessage(emailMessage, 'Please enter a valid email address', 'error');
    return;
  }
  
  // Simulate API call
  const submitButton = emailForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = 'Updating...';
  
  setTimeout(() => {
    showMessage(emailMessage, 'Email updated successfully!', 'success');
    document.getElementById('currentEmail').value = newEmail;
    document.getElementById('newEmail').value = '';
    submitButton.disabled = false;
    submitButton.textContent = 'Update Email';
  }, 1500);
});

// Password form submission
const passwordForm = document.getElementById('passwordForm');
const passwordMessage = document.getElementById('passwordMessage');

passwordForm.addEventListener('submit', (e) => {
  e.preventDefault();
  
  const currentPassword = document.getElementById('currentPassword').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  
  // Validation
  if (!currentPassword || !newPassword || !confirmPassword) {
    showMessage(passwordMessage, 'Please fill in all password fields', 'error');
    return;
  }
  
  if (newPassword.length < 8) {
    showMessage(passwordMessage, 'New password must be at least 8 characters long', 'error');
    return;
  }
  
  if (newPassword !== confirmPassword) {
    showMessage(passwordMessage, 'New passwords do not match', 'error');
    return;
  }
  
  if (currentPassword === newPassword) {
    showMessage(passwordMessage, 'New password must be different from current password', 'error');
    return;
  }
  
  // Simulate API call
  const submitButton = passwordForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = 'Changing...';
  
  setTimeout(() => {
    showMessage(passwordMessage, 'Password changed successfully!', 'success');
    passwordForm.reset();
    submitButton.disabled = false;
    submitButton.textContent = 'Change Password';
  }, 1500);
});

// Helper functions
function showMessage(element, message, type) {
  element.textContent = message;
  element.className = `form-message ${type}`;
  
  if (type === 'success') {
    setTimeout(() => {
      element.style.display = 'none';
    }, 5000);
  }
}

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Linked accounts functions
function disconnectAccount(provider) {
  if (confirm(`Are you sure you want to disconnect your ${provider} account?`)) {
    alert(`${provider} account disconnected successfully!`);
    // In a real app, this would make an API call
  }
}

function connectAccount(provider) {
  alert(`Connecting to ${provider}... This would open an OAuth flow in a real application.`);
  // In a real app, this would initiate OAuth flow
}

// Close mobile menu when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('.navbar-container') && navLinks.classList.contains('active')) {
    mobileMenuToggle.classList.remove('active');
    navLinks.classList.remove('active');
  }
});

// Close mobile menu when window is resized to desktop
window.addEventListener('resize', () => {
  if (window.innerWidth > 768 && navLinks.classList.contains('active')) {
    mobileMenuToggle.classList.remove('active');
    navLinks.classList.remove('active');
  }
});
