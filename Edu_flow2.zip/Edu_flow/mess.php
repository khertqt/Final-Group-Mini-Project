<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <title>EduFlow Hub - Messages</title>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="mess.css" />
  </head>
  <body>
    <div class="app">
      <!-- Sticky Top Navbar -->
      <nav class="top-navbar">
        <div class="navbar-container">
          <div class="logo-section">
            <div class="logo-icon">
              <div class="logo-image"></div>
            </div>
            <div class="logo-text">
              <h1 class="logo-title">EduFlow Hub</h1>
              <p class="logo-subtitle">Smart Learning Flow</p>
            </div>
          </div>

          <div class="nav-links">
            <a class="nav-button" href="dashboard.php">
              <img class="nav-icon" src="https://c.animaapp.com/mil9laobT8VDlu/img/icon-4.svg" alt="" />
              <span>Dashboard</span>
            </a>
            <a class="nav-button" href="classes.php">
              <img class="nav-icon" src="https://c.animaapp.com/mil9laobT8VDlu/img/icon-5.svg" alt="" />
              <span>Classes</span>
            </a>
            <a class="nav-button" href="ass.php">
              <img class="nav-icon" src="https://c.animaapp.com/mil9laobT8VDlu/img/icon.svg" alt="" />
              <span>Assignments</span>
            </a>
            <a class="nav-button" href="study.php">
              <img class="nav-icon" src="https://c.animaapp.com/mil9laobT8VDlu/img/icon-6.svg" alt="" />
              <span>Study Planner</span>
            </a>
            <a class="nav-button active"  href="mess.php">
              <img class="nav-icon" src="https://c.animaapp.com/mil9laobT8VDlu/img/icon-7.svg" alt="" />
              <span>Messages</span>
            </a>
            <a class="nav-button" href="notif.php">
              <img class="nav-icon" src="https://c.animaapp.com/mil9laobT8VDlu/img/icon-2.svg" alt="" />
              <span>Notifications</span>
              <span class="badge">3</span>
            </a>
          </div>

          <div class="user-section">
            <a class="notification-btn" href="settings.php">
              <img src="https://c.animaapp.com/mil9laobT8VDlu/img/button.svg" alt="Notifications" />
            </a>
            <a class="user-profile" href="profile.php">
              <div class="user-avatar">
                <span>KG</span>
              </div>
              <div class="user-info">
                <p class="user-name">Khert Galarde</p>
                <p class="user-role">Student</p>
              </div>
            </a>
          </div>
        </div>
      </nav>

      <!-- Main Content -->
      <main class="main-content">
        <div class="messages-container">
          <!-- Header -->
          <div class="messages-header">
            <div class="header-text">
              <h2>Messages</h2>
              <p>Communicate with instructors and classmates.</p>
            </div>
            <button class="new-message-btn">
              <img src="https://c.animaapp.com/mil9laobT8VDlu/img/icon-3.svg" alt="" />
              <span>New Message</span>
            </button>
          </div>

          <!-- Messages Layout -->
          <div class="messages-layout">
            <!-- Conversations Sidebar -->
            <aside class="conversations-sidebar">
              <div class="sidebar-header">
                <h3>Conversations</h3>
                <p>Your recent messages</p>
              </div>
              <div class="sidebar-content">
                <div class="search-box">
                  <img class="search-icon" src="https://c.animaapp.com/mil9laobT8VDlu/img/icon-1.svg" alt="" />
                  <input type="text" placeholder="Search messages..." id="searchInput" />
                </div>
                <div class="conversations-list" id="conversationsList">
                  <!-- Conversations will be rendered here -->
                </div>
              </div>
            </aside>

            <!-- Chat Area -->
            <section class="chat-area">
              <div class="chat-header" id="chatHeader">
                <div class="chat-user-avatar">
                  <span>MS</span>
                </div>
                <div class="chat-user-info">
                  <h3>Prof. Maria Santos</h3>
                  <p>Instructor - Web Development</p>
                </div>
              </div>
              <div class="chat-messages" id="chatMessages">
                <!-- Messages will be rendered here -->
              </div>
              <div class="chat-input-area">
                <form class="message-form" id="messageForm">
                  <button type="button" class="attach-btn">
                    <img src="https://c.animaapp.com/mil9laobT8VDlu/img/button-1.svg" alt="Attach" />
                  </button>
                  <textarea 
                    id="messageInput" 
                    placeholder="Type your message..." 
                    rows="1"
                  ></textarea>
                  <button type="submit" class="send-btn">
                    <img src="https://c.animaapp.com/mil9laobT8VDlu/img/button-2.svg" alt="Send" />
                  </button>
                </form>
                <p class="input-hint">Press Enter to send, Shift + Enter for new line</p>
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>

    <script src="mess.js"></script>
  </body>
</html>
