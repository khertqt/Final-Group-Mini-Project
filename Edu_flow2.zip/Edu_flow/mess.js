// Mock data for conversations
const conversations = [
  {
    id: 1,
    name: 'Prof. Maria Santos',
    initials: 'MS',
    role: 'Instructor - Web Development',
    lastMessage: 'Please check the updated rubric.',
    time: '10 mins ago',
    unread: 2,
    messages: [
      { id: 1, sender: 'Prof. Maria Santos', text: 'Good morning! I wanted to remind everyone about the upcoming project deadline.', time: '9:30 AM', sent: false },
      { id: 2, sender: 'You', text: 'Good morning, Prof. Santos! Thank you for the reminder. I have a question about the rubric.', time: '9:35 AM', sent: true },
      { id: 3, sender: 'Prof. Maria Santos', text: 'Of course! What would you like to know?', time: '9:40 AM', sent: false },
      { id: 4, sender: 'You', text: 'I wanted to clarify the requirements for the responsive design portion. Should we support mobile-first or desktop-first approach?', time: '9:42 AM', sent: true },
      { id: 5, sender: 'Prof. Maria Santos', text: 'Great question! Please use mobile-first approach. I\'ve updated the rubric with more details. Please check the updated rubric.', time: '9:45 AM', sent: false }
    ]
  },
  {
    id: 2,
    name: 'John Classmate',
    initials: 'JC',
    role: 'Student - CS 3rd Year',
    lastMessage: 'Can you help with Activity 2?',
    time: '1 hour ago',
    unread: 1,
    messages: [
      { id: 1, sender: 'John Classmate', text: 'Hey! Are you free to discuss Activity 2?', time: '2:15 PM', sent: false },
      { id: 2, sender: 'You', text: 'Sure! What do you need help with?', time: '2:20 PM', sent: true },
      { id: 3, sender: 'John Classmate', text: 'Can you help with Activity 2?', time: '2:25 PM', sent: false }
    ]
  },
  {
    id: 3,
    name: 'Prof. Roberto Reyes',
    initials: 'RR',
    role: 'Instructor - Data Structures',
    lastMessage: 'Class on Friday will be asynchronous.',
    time: '2 hours ago',
    unread: 0,
    messages: [
      { id: 1, sender: 'Prof. Roberto Reyes', text: 'Hello class! Just a quick update.', time: '1:00 PM', sent: false },
      { id: 2, sender: 'Prof. Roberto Reyes', text: 'Class on Friday will be asynchronous.', time: '1:01 PM', sent: false }
    ]
  },
  {
    id: 4,
    name: 'Study Group - CS301',
    initials: 'SG',
    role: 'Group Chat (5 members)',
    lastMessage: 'Who wants to review tomorrow?',
    time: '3 hours ago',
    unread: 0,
    messages: [
      { id: 1, sender: 'Sarah', text: 'Anyone up for a study session?', time: '12:00 PM', sent: false },
      { id: 2, sender: 'Mike', text: 'Who wants to review tomorrow?', time: '12:15 PM', sent: false }
    ]
  },
  {
    id: 5,
    name: 'Prof. Ana Garcia',
    initials: 'AG',
    role: 'Instructor - Humanities',
    lastMessage: 'Research paper deadline extended.',
    time: '1 day ago',
    unread: 0,
    messages: [
      { id: 1, sender: 'Prof. Ana Garcia', text: 'Good news everyone!', time: 'Yesterday', sent: false },
      { id: 2, sender: 'Prof. Ana Garcia', text: 'Research paper deadline extended.', time: 'Yesterday', sent: false }
    ]
  }
];

let currentConversation = conversations[0];

// Initialize the app
function init() {
  renderConversations();
  renderChat(currentConversation);
  setupEventListeners();
}

// Render conversations list
function renderConversations() {
  const conversationsList = document.getElementById('conversationsList');
  conversationsList.innerHTML = conversations.map(conv => `
    <div class="conversation-item ${conv.id === currentConversation.id ? 'active' : ''}" data-id="${conv.id}">
      <div class="conversation-avatar">${conv.initials}</div>
      <div class="conversation-info">
        <div class="conversation-header">
          <p class="conversation-name">${conv.name}</p>
          ${conv.unread > 0 ? `<span class="unread-badge">${conv.unread}</span>` : ''}
        </div>
        <p class="conversation-role">${conv.role}</p>
        <p class="conversation-preview">${conv.lastMessage}</p>
        <p class="conversation-time">${conv.time}</p>
      </div>
    </div>
  `).join('');
}

// Render chat messages
function renderChat(conversation) {
  const chatHeader = document.getElementById('chatHeader');
  const chatMessages = document.getElementById('chatMessages');

  // Update header
  chatHeader.innerHTML = `
    <div class="chat-user-avatar">${conversation.initials}</div>
    <div class="chat-user-info">
      <h3>${conversation.name}</h3>
      <p>${conversation.role}</p>
    </div>
  `;

  // Update messages
  chatMessages.innerHTML = conversation.messages.map(msg => `
    <div class="message ${msg.sent ? 'sent' : 'received'}">
      <p class="message-sender">${msg.sender}</p>
      <div class="message-bubble">
        <p class="message-text">${msg.text}</p>
      </div>
      <p class="message-time">${msg.time}</p>
    </div>
  `).join('');

  // Scroll to bottom
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Setup event listeners
function setupEventListeners() {
  // Conversation click
  document.getElementById('conversationsList').addEventListener('click', (e) => {
    const conversationItem = e.target.closest('.conversation-item');
    if (conversationItem) {
      const convId = parseInt(conversationItem.dataset.id);
      currentConversation = conversations.find(c => c.id === convId);
      
      // Mark as read
      currentConversation.unread = 0;
      
      renderConversations();
      renderChat(currentConversation);
    }
  });

  // Message form submit
  const messageForm = document.getElementById('messageForm');
  const messageInput = document.getElementById('messageInput');

  messageForm.addEventListener('submit', (e) => {
    e.preventDefault();
    sendMessage();
  });

  // Handle Enter key (send) and Shift+Enter (new line)
  messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Auto-resize textarea
  messageInput.addEventListener('input', () => {
    messageInput.style.height = 'auto';
    messageInput.style.height = messageInput.scrollHeight + 'px';
  });

  // Search functionality
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const conversationItems = document.querySelectorAll('.conversation-item');
    
    conversationItems.forEach(item => {
      const name = item.querySelector('.conversation-name').textContent.toLowerCase();
      const preview = item.querySelector('.conversation-preview').textContent.toLowerCase();
      
      if (name.includes(searchTerm) || preview.includes(searchTerm)) {
        item.style.display = 'flex';
      } else {
        item.style.display = 'none';
      }
    });
  });
}

// Send message function
function sendMessage() {
  const messageInput = document.getElementById('messageInput');
  const messageText = messageInput.value.trim();

  if (messageText) {
    const newMessage = {
      id: currentConversation.messages.length + 1,
      sender: 'You',
      text: messageText,
      time: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
      sent: true
    };

    currentConversation.messages.push(newMessage);
    currentConversation.lastMessage = messageText;
    currentConversation.time = 'Just now';

    renderChat(currentConversation);
    renderConversations();

    messageInput.value = '';
    messageInput.style.height = 'auto';

    // Simulate response after 2 seconds
    setTimeout(() => {
      const response = {
        id: currentConversation.messages.length + 1,
        sender: currentConversation.name,
        text: 'Thank you for your message! I\'ll get back to you soon.',
        time: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
        sent: false
      };

      currentConversation.messages.push(response);
      currentConversation.lastMessage = response.text;
      currentConversation.time = 'Just now';

      renderChat(currentConversation);
      renderConversations();
    }, 2000);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);
