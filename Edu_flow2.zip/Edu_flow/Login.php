<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="login.css" />
  </head>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const rememberMe = document.getElementById("rememberMe");
  const emailInput = document.getElementById("input-1");
  const signInBtn = document.getElementById("signInBtn");
  const passwordInput = document.getElementById("password");
  const togglePassword = document.getElementById("togglePassword");

  signInBtn.addEventListener("click", function () {
    if (emailInput.value === "" || passwordInput.value === "") {
      alert("Please enter email and password");
      return;
    }
    window.location.href = "dashboard.php";
  });

  if (localStorage.getItem("rememberEmail")) {
    emailInput.value = localStorage.getItem("rememberEmail");
    rememberMe.checked = true;
  }

  rememberMe.addEventListener("change", () => {
    if (rememberMe.checked) {
      localStorage.setItem("rememberEmail", emailInput.value);
    } else {
      localStorage.removeItem("rememberEmail");
    }
  });

  // Password visibility toggle
  togglePassword.addEventListener("click", function () {
    passwordInput.type = passwordInput.type === "password" ? "text" : "password";
  });
});

// Password visibility toggle + icon change
togglePassword.addEventListener("click", function () {
  const isHidden = passwordInput.type === "password";

  if (isHidden) {
    passwordInput.type = "text";
    togglePassword.src = "https://c.animaapp.com/80cXYxUU/img/icon-eye-open.svg"; // OPEN EYE
  } else {
    passwordInput.type = "password";
    togglePassword.src = "https://c.animaapp.com/80cXYxUU/img/button.svg"; // CLOSED EYE
  }
});

</script>



  <body>
    <div class="login" data-model-id="8:3">
      <div class="container-wrapper">
        <div class="container">
          <div class="div">
            <div class="container-2">
              <div class="image-eduflow-hub-wrapper"><div class="image-eduflow-hub"></div></div>
              <div class="container-3">
                <div class="heading"><div class="text-wrapper">EduFlow Hub</div></div>
                <div class="paragraph"><p class="p">Powered by Smart Learning Flow</p></div>
              </div>
            </div>
            <div class="container-4">
              <div class="div-2"><div class="text-wrapper-2">Welcome Back!</div></div>
              <div class="access-your-classes-wrapper">
                <p class="access-your-classes">
                  Access your classes, assignments, and academic progress all in one place. Stay organized and connected
                  with your educational journey.
                </p>
              </div>
            </div>
            <div class="container-5">
              <div class="container-6">
                <img class="img" src="https://c.animaapp.com/80cXYxUU/img/container.svg" />
                <div class="container-7">
                  <div class="paragraph"><div class="text-wrapper-3">Manage Your Classes</div></div>
                  <div class="div-wrapper">
                    <p class="text-wrapper-4">View schedules, materials, and assignments</p>
                  </div>
                </div>
              </div>
              <div class="container-6">
                <img class="img" src="https://c.animaapp.com/80cXYxUU/img/container-1.svg" />
                <div class="container-8">
                  <div class="paragraph"><div class="text-wrapper-3">Track Your Progress</div></div>
                  <div class="div-wrapper"><p class="text-wrapper-5">Monitor grades and academic performance</p></div>
                </div>
              </div>
              <div class="container-6">
                <img class="img" src="https://c.animaapp.com/80cXYxUU/img/container-2.svg" />
                <div class="container-9">
                  <div class="paragraph"><div class="text-wrapper-3">Stay Connected</div></div>
                  <div class="div-wrapper">
                    <p class="text-wrapper-6">Communicate with instructors and classmates</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <div class="card-title"><div class="text-wrapper-7">Sign In</div></div>
              <div class="card-description">
                <p class="text-wrapper-8">Enter your credentials to access your account</p>
              </div>
            </div>
            <div class="div-3">
              <div class="container-10">
                <div class="primitive-label"><label class="text-wrapper-9" for="input-1">Email Address</label></div>
                <div class="div-2">
                  <input class="input" placeholder="your.email@school.edu" type="email" id="input-1" />
                  <img class="icon" src="https://c.animaapp.com/80cXYxUU/img/icon.svg" />
                </div>
              </div>
              <div class="container-10">
                <div class="primitive-label"><div class="text-wrapper-9">Password</div></div>
                <div class="div-2">
                  <input class="input" placeholder="Enter your password" type="password" id="password" />
                  <img class="icon" src="https://c.animaapp.com/80cXYxUU/img/icon-1.svg" />
                  <img class="button" id="togglePassword" src="https://c.animaapp.com/80cXYxUU/img/button.svg" data-open="false" style="cursor:pointer;" />
                </div>
              </div>
              <div class="container-11">
                <div class="remember-me">
                  <label class="remember-wrapper">
                    <input type="checkbox" class="remember-checkbox" id="rememberMe" />
                    <span class="custom-check"></span>
                    <span class="remember-text">Remember me</span>
                  </label>
                </div>
                <div class="link" onclick="window.location.href='forgetpass.html'" style="cursor:pointer;">
                    <div class="text-wrapper-12">Forgot password?</div>
                </div>
              </div>
              <button class="button-2" id="signInBtn">
                <div class="text-wrapper-13">Log In</div> 
              </button>
              <div class="container-13">
                <div class="text"></div>
                <div class="or-continue-with-wrapper"><div class="or-continue-with">OR CONTINUE WITH</div></div>
              </div>
              <div class="container-14">
              <button class="button-3">
                  <img class="img-2" src="https://c.animaapp.com/80cXYxUU/img/login.svg" />
                  <div class="text-wrapper-14">Google</div>
              </button>

              <button class="button-4">
                  <img class="img-3" src="https://c.animaapp.com/80cXYxUU/img/login-1.svg" />
                  <div class="text-wrapper-15">Facebook</div>
              </button>
              </div>

            <div class="container-15">
                <div class="don-t-have-an">Don&#39;t have an account?</div>
                <div class="link-2" onclick="window.location.href='signup.php'" style="cursor:pointer;">
                    <div class="text-wrapper-16">Sign up</div>
                </div>
            </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
