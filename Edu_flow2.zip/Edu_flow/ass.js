// Tab filtering functionality
const tabButtons = document.querySelectorAll('.tab-button');
const assignmentCards = document.querySelectorAll('.assignment-card');

tabButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Remove active class from all buttons
    tabButtons.forEach(btn => btn.classList.remove('active'));
    // Add active class to clicked button
    button.classList.add('active');

    const filterText = button.textContent.trim().toLowerCase();

    // Filter assignments
    assignmentCards.forEach(card => {
      if (filterText === 'all') {
        card.style.display = 'flex';
      } else {
        const cardClass = card.className.toLowerCase();
        if (cardClass.includes(filterText)) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      }
    });
  });
});


// Submit assignment functionality
function handleSubmit(assignmentName) {
  console.log(`Submit clicked for: ${assignmentName}`);
  const confirmed = confirm(`Are you sure you want to submit "${assignmentName}"?\n\nThis would open a file upload dialog or submission form.`);
  if (confirmed) {
    alert(`Submission process started for "${assignmentName}"`);
  }
}

// Submit late functionality
function handleSubmitLate(assignmentName) {
  console.log(`Submit Late clicked for: ${assignmentName}`);
  const confirmed = confirm(`This assignment is overdue. Late submissions may receive reduced points.\n\nDo you want to proceed with submitting "${assignmentName}"?`);
  if (confirmed) {
    alert(`Late submission process started for "${assignmentName}"`);
  }
}

// View details functionality
function handleViewDetails(assignmentName) {
  console.log(`View Details clicked for: ${assignmentName}`);
  alert(`Viewing details for "${assignmentName}"\n\nThis would open a detailed view with:\n- Full assignment description\n- Rubric and grading criteria\n- Submission history\n- Related resources`);
}

// View feedback functionality
function handleViewFeedback(assignmentName) {
  console.log(`View Feedback clicked for: ${assignmentName}`);
  alert(`Viewing feedback for "${assignmentName}"\n\nThis would show:\n- Instructor comments\n- Grade breakdown\n- Areas for improvement\n- Strengths highlighted`);
}




// Add smooth scroll behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Add animation on scroll for assignment cards
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '0';
      entry.target.style.transform = 'translateY(20px)';
      setTimeout(() => {
        entry.target.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }, 100);
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

assignmentCards.forEach(card => {
  observer.observe(card);
});

console.log('EduFlow Hub - Assignment Dashboard Loaded');
console.log('Features:');
console.log('- Sticky navigation bar');
console.log('- Responsive design (mobile, tablet, desktop)');
console.log('- Functional tab filtering');
console.log('- Interactive buttons with alerts');
console.log('- Smooth animations');
