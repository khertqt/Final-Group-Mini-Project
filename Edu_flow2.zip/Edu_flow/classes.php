<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EduFlow Hub - My Classes</title>
  <link rel="stylesheet" href="globals.css">
  <link rel="stylesheet" href="classes.css">
</head>
<body>
  <nav class="top-navbar">
    <div class="navbar-container">
      <div class="brand">
        <div class="logo-wrapper">
          <div class="logo-icon"></div>
        </div>
        <div class="brand-text">
          <h1 class="brand-name">EduFlow Hub</h1>
          <p class="brand-tagline">Smart Learning Flow</p>
        </div>
      </div>

      <div class="nav-links">
        <button class="nav-button" onclick="location.href='dashboard.php'">
          <img class="nav-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-18.svg" alt="">
          <span>Dashboard</span>
        </button>
        <button class="nav-button active" onclick="location.href='classes.php'">
          <img class="nav-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-33.svg" alt="">
          <span>Classes</span>
        </button>
        <button class="nav-button" onclick="location.href='ass.php'">
          <img class="nav-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-21.svg" alt="">
          <span>Assignments</span>
        </button>
        <button class="nav-button" onclick="location.href='study.php'">
          <img class="nav-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-26.svg" alt="">
          <span>Study Planner</span>
        </button>
        <button class="nav-button" onclick="location.href='mess.php'">
          <img class="nav-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-3.svg" alt="">
          <span>Messages</span>
        </button>
        <button class="nav-button" onclick="location.href='notif.php'">
          <img class="nav-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-23.svg" alt="">
          <span>Notifications</span>
          <span class="badge">3</span>
        </button>
      </div>

      <div class="user-section">
        <button class="settings-button" onclick="location.href='settings.php'">
          <img src="https://c.animaapp.com/mil85dpjM40oPO/img/button.svg" alt="Settings">
        </button>
        <button class="user-profile" onclick="location.href='profile.php'">
          <div class="avatar">  
            <span>KG</span>
          </div>
          <div class="user-info">
            <p class="user-name">Khert Galarde</p>
            <p class="user-role">Student</p>
          </div>
        </button>
      </div>
    </div>
  </nav>

  <main class="main-content">
    <header class="page-header">
      <h2 class="page-title">My Classes</h2>
      <p class="page-description">View and manage your enrolled classes.</p>
    </header>

    <section class="stats-grid">
      <div class="stat-card">
        <img class="stat-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container-7.svg" alt="">
        <div class="stat-content">
          <p class="stat-number">5</p>
          <p class="stat-label">Total Classes</p>
        </div>
      </div>
      <div class="stat-card">
        <img class="stat-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container-2.svg" alt="">
        <div class="stat-content">
          <p class="stat-number">3</p>
          <p class="stat-label">Classes Today</p>
        </div>
      </div>
      <div class="stat-card">
        <img class="stat-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container-3.svg" alt="">
        <div class="stat-content">
          <p class="stat-number">5</p>
          <p class="stat-label">Instructors</p>
        </div>
      </div>
    </section>

    <section class="classes-grid">
      <article class="class-card blue-border">
        <div class="card-header">
          <div class="card-header-top">
            <img class="class-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container.svg" alt="">
            <span class="course-code">CS301</span>
          </div>
          <h3 class="class-title">Web Development 101</h3>
          <p class="class-type">In-Person</p>
        </div>
        <div class="card-body">
          <div class="class-details">
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-6.svg" alt="">
              <span>Prof. Maria Santos</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-9.svg" alt="">
              <span>MWF 9:00 AM - 10:30 AM</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-1.svg" alt="">
              <span>Room 304</span>
            </div>
          </div>
          <div class="card-actions">
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-2.svg" alt="">
              <span>Materials</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon.svg" alt="">
              <span>Details</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-3.svg" alt="">
              <span>Contact</span>
            </button>
          </div>
        </div>
      </article>

      <article class="class-card green-border">
        <div class="card-header">
          <div class="card-header-top">
            <img class="class-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container.svg" alt="">
            <span class="course-code">CS302</span>
          </div>
          <h3 class="class-title">Data Structures & Algorithms</h3>
          <p class="class-type">Online</p>
        </div>
        <div class="card-body">
          <div class="class-details">
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-6.svg" alt="">
              <span>Prof. Roberto Reyes</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-9.svg" alt="">
              <span>TTh 1:00 PM - 2:30 PM</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-1.svg" alt="">
              <span>Online</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-7.svg" alt="">
              <a href="#" class="online-link">
                Join Online Class
                <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-5.svg" alt="">
              </a>
            </div>
          </div>
          <div class="card-actions">
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-2.svg" alt="">
              <span>Materials</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon.svg" alt="">
              <span>Details</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-3.svg" alt="">
              <span>Contact</span>
            </button>
          </div>
        </div>
      </article>

      <article class="class-card purple-border">
        <div class="card-header">
          <div class="card-header-top">
            <img class="class-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container.svg" alt="">
            <span class="course-code">HUM201</span>
          </div>
          <h3 class="class-title">Humanities</h3>
          <p class="class-type">In-Person</p>
        </div>
        <div class="card-body">
          <div class="class-details">
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-6.svg" alt="">
              <span>Prof. Ana Garcia</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-9.svg" alt="">
              <span>MW 3:00 PM - 4:30 PM</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-1.svg" alt="">
              <span>Room 105</span>
            </div>
          </div>
          <div class="card-actions">
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-2.svg" alt="">
              <span>Materials</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon.svg" alt="">
              <span>Details</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-3.svg" alt="">
              <span>Contact</span>
            </button>
          </div>
        </div>
      </article>

      <article class="class-card orange-border">
        <div class="card-header">
          <div class="card-header-top">
            <img class="class-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container.svg" alt="">
            <span class="course-code">CS303</span>
          </div>
          <h3 class="class-title">Database Management</h3>
          <p class="class-type">Laboratory</p>
        </div>
        <div class="card-body">
          <div class="class-details">
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-6.svg" alt="">
              <span>Prof. Carlos Martinez</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-9.svg" alt="">
              <span>TTh 10:00 AM - 11:30 AM</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-1.svg" alt="">
              <span>Lab 201</span>
            </div>
          </div>
          <div class="card-actions">
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-2.svg" alt="">
              <span>Materials</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon.svg" alt="">
              <span>Details</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-3.svg" alt="">
              <span>Contact</span>
            </button>
          </div>
        </div>
      </article>

      <article class="class-card red-border">
        <div class="card-header">
          <div class="card-header-top">
            <img class="class-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/container.svg" alt="">
            <span class="course-code">PE101</span>
          </div>
          <h3 class="class-title">Physical Education</h3>
          <p class="class-type">In-Person</p>
        </div>
        <div class="card-body">
          <div class="class-details">
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-6.svg" alt="">
              <span>Coach David Cruz</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-9.svg" alt="">
              <span>F 2:00 PM - 4:00 PM</span>
            </div>
            <div class="detail-item">
              <img class="detail-icon" src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-1.svg" alt="">
              <span>Gymnasium</span>
            </div>
          </div>
          <div class="card-actions">
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-2.svg" alt="">
              <span>Materials</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon.svg" alt="">
              <span>Details</span>
            </button>
            <button class="action-button">
              <img src="https://c.animaapp.com/mil85dpjM40oPO/img/icon-3.svg" alt="">
              <span>Contact</span>
            </button>
          </div>
        </div>
      </article>
    </section>
  </main>
</body>
</html>
