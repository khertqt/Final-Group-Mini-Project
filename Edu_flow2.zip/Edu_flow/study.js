let editingTaskCard = null;

document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
});

function initializeApp() {
  updateCounts();
  initializeFilters();
  initializeStatusDropdowns();
  initializeDeleteButtons();
  initializeTaskModal();
  initializeEditButtons();
  setInitialProgressBars();
}

function setInitialProgressBars() {
  const progressBars = document.querySelectorAll('.progress-bar[data-progress]');
  progressBars.forEach(bar => {
    const progress = bar.dataset.progress;
    setTimeout(() => {
      bar.style.width = progress + '%';
    }, 100);
  });
}

function initializeTaskModal() {
  const modal = document.getElementById('taskModal');
  const newTaskBtn = document.getElementById('newTaskBtn');
  const closeModal = document.getElementById('closeModal');
  const cancelBtn = document.getElementById('cancelBtn');
  const taskForm = document.getElementById('taskForm');

  newTaskBtn.addEventListener('click', function() {
    openModal('new');
  });

  closeModal.addEventListener('click', closeTaskModal);
  cancelBtn.addEventListener('click', closeTaskModal);

  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      closeTaskModal();
    }
  });

  taskForm.addEventListener('submit', function(e) {
    e.preventDefault();
    if (editingTaskCard) {
      updateTask();
    } else {
      createTask();
    }
  });
}

function openModal(mode, taskCard = null) {
  const modal = document.getElementById('taskModal');
  const modalTitle = document.getElementById('modalTitle');
  const submitBtn = document.getElementById('submitBtn');
  
  editingTaskCard = taskCard;
  
  if (mode === 'edit' && taskCard) {
    modalTitle.textContent = 'Edit Task';
    submitBtn.textContent = 'Update Task';
    populateFormWithTaskData(taskCard);
  } else {
    modalTitle.textContent = 'New Task';
    submitBtn.textContent = 'Create Task';
    document.getElementById('taskForm').reset();
    setDefaultDateTime();
  }
  
  modal.classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeTaskModal() {
  const modal = document.getElementById('taskModal');
  modal.classList.remove('show');
  document.body.style.overflow = '';
  editingTaskCard = null;
  document.getElementById('taskForm').reset();
}

function setDefaultDateTime() {
  const dateInput = document.getElementById('taskDate');
  const timeInput = document.getElementById('taskTime');
  
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  const year = tomorrow.getFullYear();
  const month = String(tomorrow.getMonth() + 1).padStart(2, '0');
  const day = String(tomorrow.getDate()).padStart(2, '0');
  
  dateInput.value = `${year}-${month}-${day}`;
  timeInput.value = '18:00';
}

function populateFormWithTaskData(taskCard) {
  const title = taskCard.querySelector('.text-wrapper-23, .text-wrapper-33, .text-wrapper-34').textContent;
  const description = taskCard.querySelector('.text-wrapper-26').textContent;
  const course = taskCard.querySelector('.text-wrapper-21').textContent;
  const priority = taskCard.querySelector('.high-priority-wrapper, .medium-priority-wrapper, .badge-5').textContent;
  const status = taskCard.dataset.status;
  
  const dueDateText = taskCard.querySelector('.text-wrapper-27').textContent.replace('Due: ', '');
  const timeText = taskCard.querySelector('.text-wrapper-28').textContent;
  
  const dateParts = dueDateText.split('/');
  const formattedDate = `${dateParts[2]}-${dateParts[0]}-${dateParts[1]}`;
  
  document.getElementById('taskTitle').value = title;
  document.getElementById('taskDescription').value = description;
  document.getElementById('taskCourse').value = course;
  document.getElementById('taskPriority').value = priority;
  document.getElementById('taskStatus').value = status;
  document.getElementById('taskDate').value = formattedDate;
  document.getElementById('taskTime').value = timeText;
}

function createTask() {
  const formData = getFormData();
  const taskCard = createTaskCard(formData);
  
  const taskList = document.querySelector('.task-list');
  taskList.insertBefore(taskCard, taskList.firstChild);
  
  initializeTaskCardEvents(taskCard);
  updateCounts();
  closeTaskModal();
  
  taskCard.style.opacity = '0';
  taskCard.style.transform = 'translateY(-20px)';
  setTimeout(() => {
    taskCard.style.transition = 'all 0.3s ease';
    taskCard.style.opacity = '1';
    taskCard.style.transform = 'translateY(0)';
  }, 10);
}

function updateTask() {
  const formData = getFormData();
  
  editingTaskCard.dataset.status = formData.status;
  
  editingTaskCard.querySelector('.text-wrapper-23, .text-wrapper-33, .text-wrapper-34').textContent = formData.title;
  editingTaskCard.querySelector('.text-wrapper-26').textContent = formData.description;
  editingTaskCard.querySelector('.text-wrapper-21').textContent = formData.course;
  editingTaskCard.querySelector('.text-wrapper-27').textContent = 'Due: ' + formData.dueDate;
  editingTaskCard.querySelector('.text-wrapper-28').textContent = formData.time;
  
  const priorityBadge = editingTaskCard.querySelector('.high-priority-wrapper, .medium-priority-wrapper, .badge-5');
  priorityBadge.className = formData.priority.includes('High') ? 'high-priority-wrapper' : 
                            formData.priority.includes('Medium') ? 'medium-priority-wrapper' : 'badge-5';
  priorityBadge.querySelector('.text-wrapper-25').textContent = formData.priority;
  
  const statusBadge = editingTaskCard.querySelector('.status-badge');
  const statusText = editingTaskCard.querySelector('.status-text');
  const statusDropdown = editingTaskCard.querySelector('.status-dropdown');
  
  updateTaskStatus(editingTaskCard, formData.status, statusText, statusBadge);
  
  closeTaskModal();
}

function getFormData() {
  const title = document.getElementById('taskTitle').value;
  const description = document.getElementById('taskDescription').value;
  const course = document.getElementById('taskCourse').value;
  const priority = document.getElementById('taskPriority').value;
  const status = document.getElementById('taskStatus').value;
  const date = document.getElementById('taskDate').value;
  const time = document.getElementById('taskTime').value;
  
  const dateObj = new Date(date);
  const month = String(dateObj.getMonth() + 1).padStart(2, '0');
  const day = String(dateObj.getDate()).padStart(2, '0');
  const year = dateObj.getFullYear();
  const formattedDate = `${month}/${day}/${year}`;
  
  return {
    title,
    description,
    course,
    priority,
    status,
    dueDate: formattedDate,
    time
  };
}

function createTaskCard(data) {
  const card = document.createElement('div');
  card.className = 'card-5';
  card.dataset.status = data.status;
  
  const statusConfig = {
    'todo': { text: 'To Do', badgeClass: 'badge-3', icon: 'container-5.svg' },
    'in-progress': { text: 'In Progress', badgeClass: 'badge-2', icon: 'container-3.svg' },
    'completed': { text: 'Completed', badgeClass: 'badge-4', icon: 'container-6.svg' }
  };
  
  const config = statusConfig[data.status];
  const priorityClass = data.priority.includes('High') ? 'high-priority-wrapper' : 
                        data.priority.includes('Medium') ? 'medium-priority-wrapper' : 'badge-5';
  
  const progressBarHTML = data.status === 'in-progress' ? `
    <div class="progress-bar-container">
      <div class="progress-bar-wrapper">
        <div class="progress-bar" data-progress="0" style="width: 0%"></div>
      </div>
      <div class="progress-text">0% Complete</div>
    </div>
  ` : '';
  
  card.innerHTML = `
    <div class="task-list-2">
      <img class="container-14" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/${config.icon}" />
      <div class="container-15">
        <div class="div-2">
          <div class="card-title-2"><div class="text-wrapper-23">${data.title}</div></div>
          <div class="${config.badgeClass} status-badge"><div class="text-wrapper-24 text-wrapper-25">${config.text}</div></div>
          <div class="${priorityClass}"><div class="text-wrapper-25">${data.priority}</div></div>
        </div>
        ${progressBarHTML}
        <div class="div-wrapper-3"><div class="text-wrapper-21">${data.course}</div></div>
      </div>
    </div>
    <div class="card-content">
      <div class="div-wrapper-2">
        <p class="text-wrapper-26">${data.description}</p>
      </div>
      <div class="task-list-3">
        <div class="container-16">
          <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-5.svg" />
          <div class="text-3"><div class="text-wrapper-27">Due: ${data.dueDate}</div></div>
        </div>
        <div class="container-17">
          <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-7.svg" />
          <div class="text"><div class="text-wrapper-28">${data.time}</div></div>
        </div>
      </div>
      <div class="task-list-4">
        <button class="button-9">
          <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-13.svg" />
          <div class="text-wrapper-29">View Details</div>
        </button>
        <div class="primitive-button-5 status-dropdown">
          <div class="primitive-span"><div class="text-wrapper-30 status-text">${config.text}</div></div>
          <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-1.svg" />
          <div class="status-menu">
            <div class="status-option" data-status="todo">To Do</div>
            <div class="status-option" data-status="in-progress">In Progress</div>
            <div class="status-option" data-status="completed">Completed</div>
          </div>
        </div>
        <div class="container-18"></div>
        <button class="button-10 edit-btn">
          <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-12.svg" />
          <div class="text-wrapper-31">Edit</div>
        </button>
        <button class="button-11 delete-btn">
          <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-4.svg" />
          <div class="text-wrapper-32">Delete</div>
        </button>
      </div>
    </div>
  `;
  
  return card;
}

function initializeTaskCardEvents(taskCard) {
  const dropdown = taskCard.querySelector('.status-dropdown');
  dropdown.addEventListener('click', function(e) {
    e.stopPropagation();
    document.querySelectorAll('.status-dropdown').forEach(d => {
      if (d !== dropdown) d.classList.remove('open');
    });
    this.classList.toggle('open');
  });

  const options = dropdown.querySelectorAll('.status-option');
  options.forEach(option => {
    option.addEventListener('click', function(e) {
      e.stopPropagation();
      const newStatus = this.dataset.status;
      const statusText = dropdown.querySelector('.status-text');
      const statusBadge = taskCard.querySelector('.status-badge');
      updateTaskStatus(taskCard, newStatus, statusText, statusBadge);
      dropdown.classList.remove('open');
    });
  });

  const deleteBtn = taskCard.querySelector('.delete-btn');
  deleteBtn.addEventListener('click', function() {
    if (confirm('Are you sure you want to delete this task?')) {
      taskCard.style.opacity = '0';
      taskCard.style.transform = 'scale(0.95)';
      taskCard.style.transition = 'all 0.3s ease';
      setTimeout(() => {
        taskCard.remove();
        updateCounts();
      }, 300);
    }
  });

  const editBtn = taskCard.querySelector('.edit-btn');
  editBtn.addEventListener('click', function() {
    openModal('edit', taskCard);
  });
}

function initializeEditButtons() {
  const editButtons = document.querySelectorAll('.edit-btn');
  editButtons.forEach(button => {
    button.addEventListener('click', function() {
      const taskCard = this.closest('.card-5');
      openModal('edit', taskCard);
    });
  });
}

function updateCounts() {
  const tasks = document.querySelectorAll('.card-5');
  const counts = {
    all: tasks.length,
    todo: 0,
    progress: 0,
    completed: 0
  };

  tasks.forEach(task => {
    const status = task.dataset.status;
    if (status === 'todo') counts.todo++;
    else if (status === 'in-progress') counts.progress++;
    else if (status === 'completed') counts.completed++;
  });

  document.querySelector('.count-all').textContent = counts.all;
  document.querySelector('.count-todo').textContent = counts.todo;
  document.querySelector('.count-progress').textContent = counts.progress;
  document.querySelector('.count-completed').textContent = counts.completed;

  const statCards = document.querySelectorAll('.container-8 > div');
  if (statCards[0]) statCards[0].querySelector('.text-wrapper-15').textContent = counts.all;
  if (statCards[1]) statCards[1].querySelector('.text-wrapper-15').textContent = counts.todo;
  if (statCards[2]) statCards[2].querySelector('.text-wrapper-15').textContent = counts.progress;
  if (statCards[3]) statCards[3].querySelector('.text-wrapper-15').textContent = counts.completed;
}

function initializeFilters() {
  const filterButtons = document.querySelectorAll('[data-filter]');
  const tasks = document.querySelectorAll('.card-5');

  filterButtons.forEach(button => {
    button.addEventListener('click', function() {
      filterButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');

      const filter = this.dataset.filter;

      tasks.forEach(task => {
        if (filter === 'all') {
          task.style.display = 'block';
        } else {
          const taskStatus = task.dataset.status;
          task.style.display = taskStatus === filter ? 'block' : 'none';
        }
      });
    });
  });
}

function initializeStatusDropdowns() {
  const dropdowns = document.querySelectorAll('.status-dropdown');

  dropdowns.forEach(dropdown => {
    dropdown.addEventListener('click', function(e) {
      e.stopPropagation();
      
      document.querySelectorAll('.status-dropdown').forEach(d => {
        if (d !== dropdown) d.classList.remove('open');
      });
      
      this.classList.toggle('open');
    });

    const options = dropdown.querySelectorAll('.status-option');
    options.forEach(option => {
      option.addEventListener('click', function(e) {
        e.stopPropagation();
        const newStatus = this.dataset.status;
        const taskCard = dropdown.closest('.card-5');
        const statusText = dropdown.querySelector('.status-text');
        const statusBadge = taskCard.querySelector('.status-badge');
        
        updateTaskStatus(taskCard, newStatus, statusText, statusBadge);
        dropdown.classList.remove('open');
      });
    });
  });

  document.addEventListener('click', function() {
    document.querySelectorAll('.status-dropdown').forEach(d => {
      d.classList.remove('open');
    });
  });
}

function updateTaskStatus(taskCard, newStatus, statusText, statusBadge) {
  taskCard.dataset.status = newStatus;

  const statusConfig = {
    'todo': {
      text: 'To Do',
      badgeClass: 'badge-3',
      bgColor: '#ffffff',
      textColor: '#0a0a0a',
      border: '1px solid #0000001a'
    },
    'in-progress': {
      text: 'In Progress',
      badgeClass: 'badge-2',
      bgColor: '#2b7fff',
      textColor: '#ffffff',
      border: '1px solid transparent'
    },
    'completed': {
      text: 'Completed',
      badgeClass: 'badge-4',
      bgColor: '#00c950',
      textColor: '#ffffff',
      border: '1px solid transparent'
    }
  };

  const config = statusConfig[newStatus];
  statusText.textContent = config.text;
  statusBadge.className = `${config.badgeClass} status-badge`;
  statusBadge.style.backgroundColor = config.bgColor;
  statusBadge.style.color = config.textColor;
  statusBadge.style.border = config.border;
  statusBadge.querySelector('.text-wrapper-24, .text-wrapper-25').textContent = config.text;

  let progressContainer = taskCard.querySelector('.progress-bar-container');
  
  if (newStatus === 'in-progress') {
    if (!progressContainer) {
      progressContainer = document.createElement('div');
      progressContainer.className = 'progress-bar-container';
      progressContainer.innerHTML = `
        <div class="progress-bar-wrapper">
          <div class="progress-bar" data-progress="0"></div>
        </div>
        <div class="progress-text">0% Complete</div>
      `;
      
      const titleContainer = taskCard.querySelector('.div-2');
      titleContainer.appendChild(progressContainer);
      
      setTimeout(() => {
        const progressBar = progressContainer.querySelector('.progress-bar');
        const progressText = progressContainer.querySelector('.progress-text');
        const progress = 35;
        progressBar.style.width = progress + '%';
        progressBar.dataset.progress = progress;
        progressText.textContent = progress + '% Complete';
      }, 50);
    }
  } else {
    if (progressContainer) {
      progressContainer.remove();
    }
  }

  updateCounts();

  const activeFilter = document.querySelector('[data-filter].active');
  if (activeFilter) {
    const filter = activeFilter.dataset.filter;
    if (filter !== 'all' && filter !== newStatus) {
      taskCard.style.display = 'none';
    }
  }
}

function initializeDeleteButtons() {
  const deleteButtons = document.querySelectorAll('.delete-btn');
  
  deleteButtons.forEach(button => {
    button.addEventListener('click', function() {
      const taskCard = this.closest('.card-5');
      
      if (confirm('Are you sure you want to delete this task?')) {
        taskCard.style.opacity = '0';
        taskCard.style.transform = 'scale(0.95)';
        taskCard.style.transition = 'all 0.3s ease';
        
        setTimeout(() => {
          taskCard.remove();
          updateCounts();
        }, 300);
      }
    });
  });
}
