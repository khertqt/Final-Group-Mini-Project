<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="study.css" />
    <script src="study.js" defer></script>
  </head>
  <body>
    <!-- Task Modal -->
    <div id="taskModal" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <h2 id="modalTitle">New Task</h2>
          <button class="modal-close" id="closeModal">&times;</button>
        </div>
        <form id="taskForm">
          <div class="form-group">
            <label for="taskTitle">Task Title *</label>
            <input type="text" id="taskTitle" required placeholder="Enter task title">
          </div>
          
          <div class="form-group">
            <label for="taskDescription">Description *</label>
            <textarea id="taskDescription" required placeholder="Enter task description" rows="3"></textarea>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="taskCourse">Course *</label>
              <input type="text" id="taskCourse" required placeholder="e.g., Web Development 101">
            </div>
            
            <div class="form-group">
              <label for="taskPriority">Priority *</label>
              <select id="taskPriority" required>
                <option value="High Priority">High Priority</option>
                <option value="Medium Priority" selected>Medium Priority</option>
                <option value="Low Priority">Low Priority</option>
              </select>
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="taskDate">Due Date *</label>
              <input type="date" id="taskDate" required>
            </div>
            
            <div class="form-group">
              <label for="taskTime">Time *</label>
              <input type="time" id="taskTime" required>
            </div>
          </div>
          
          <div class="form-group">
            <label for="taskStatus">Status *</label>
            <select id="taskStatus" required>
              <option value="todo" selected>To Do</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          
          <div class="modal-actions">
            <button type="button" class="btn-secondary" id="cancelBtn">Cancel</button>
            <button type="submit" class="btn-primary" id="submitBtn">Create Task</button>
          </div>
        </form>
      </div>
    </div>
    <div class="study">
      <div class="top-navbar">
        <div class="container">
          <div class="div">
            <div class="image-eduflow-hub-wrapper"><div class="image-eduflow-hub"></div></div>
            <div class="container-2">
              <div class="div-2"><div class="text-wrapper">EduFlow Hub</div></div>
              <div class="paragraph"><div class="text-wrapper-2">Smart Learning Flow</div></div>
            </div>
          </div>
          <div class="container-3">
            <button class="button" onclick="window.location.href='dashboard.php'">
              <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-3.svg" />
              <div class="text"><div class="text-wrapper-3">Dashboard</div></div>
            </button>
            <button class="button-2" onclick="window.location.href='classes.php'">
              <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-15.svg" />
              <div class="text"><div class="text-wrapper-4">Classes</div></div>
            </button>
            <button class="button-3" onclick="window.location.href='ass.php'">
              <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-24.svg" />
              <div class="text"><div class="text-wrapper-5">Assignments</div></div>
            </button>
            <button class="button-4" onclick="window.location.href='study.php'">
              <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-23.svg" />
              <div class="text"><div class="text-wrapper-6">Study Planner</div></div>
            </button>
            <button class="button-5" onclick="window.location.href='mess.php'"> 
              <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon.svg" />
              <div class="text"><div class="text-wrapper-7">Messages</div></div>
            </button>
            <div class="button-6" onclick="window.location.href='notif.php'">
              <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-2.svg" />
              <div class="text"><div class="text-wrapper-8">Notifications</div></div>
              <div class="badge"><div class="text-wrapper-9">3</div></div>
            </div>
          </div>
          <div class="container-4">
            <img class="img" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/button.svg" onclick="window.location.href='settings.html'" style="cursor:pointer;"/>
            
            <div class="button-7" onclick="window.location.href='profile.php'" style="cursor:pointer;">
              <div class="div-wrapper">
                <div class="text-2"><div class="text-wrapper-10">KG</div></div>
              </div>
              <div class="container-5">
                <div class="div-wrapper-2"><div class="text-wrapper-11">Khert Galarde</div></div>
                <div class="paragraph"><div class="text-wrapper-12">Student</div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="study-planner">
        <div class="container-6">
          <div class="container-7">
            <div class="heading"><div class="text-wrapper-13">Study Planner</div></div>
            <div class="div-wrapper-3"><p class="p">Manage your study tasks and notes.</p></div>
          </div>
          <button class="button-8" id="newTaskBtn">
            <img class="icon-2" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-17.svg" />
            <div class="text-wrapper-14">New Task</div>
          </button>
        </div>
        <div class="container-8">
          <div class="card">
            <div class="study-planner-2">
              <img class="container-9" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/container-1.svg" />
              <div class="container-10">
                <div class="paragraph-2"><div class="text-wrapper-15">3</div></div>
                <div class="paragraph"><div class="text-wrapper-16">Total Tasks</div></div>
              </div>
            </div>
          </div>
          <div class="study-planner-wrapper">
            <div class="study-planner-2">
              <img class="container-9" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/container-4.svg" />
              <div class="container-11">
                <div class="paragraph-2"><div class="text-wrapper-15">1</div></div>
                <div class="paragraph"><div class="text-wrapper-17">To Do</div></div>
              </div>
            </div>
          </div>
          <div class="card-2">
            <div class="study-planner-2">
              <img class="container-9" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/container.svg" />
              <div class="container-12">
                <div class="paragraph-2"><div class="text-wrapper-15">1</div></div>
                <div class="paragraph"><div class="text-wrapper-18">In Progress</div></div>
              </div>
            </div>
          </div>
          <div class="card-3">
            <div class="study-planner-2">
              <img class="container-9" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/container-2.svg" />
              <div class="container-13">
                <div class="paragraph-2"><div class="text-wrapper-15">1</div></div>
                <div class="paragraph"><div class="text-wrapper-19">Completed</div></div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-4">
          <div class="card-header">
            <div class="card-title"><div class="text-wrapper-20">My Study Tasks</div></div>
            <div class="card-description"><p class="text-wrapper-21">Organize and track your study progress</p></div>
          </div>
          <div class="primitive-div">
            <div class="tab-list">
              <div class="primitive-button active" data-filter="all"><div class="text-wrapper-22">All (<span class="count-all">3</span>)</div></div>
              <div class="primitive-button-2" data-filter="todo"><div class="text-wrapper-22">To Do (<span class="count-todo">1</span>)</div></div>
              <div class="primitive-button-3" data-filter="in-progress"><div class="text-wrapper-22">In Progress (<span class="count-progress">1</span>)</div></div>
              <div class="primitive-button-4" data-filter="completed"><div class="text-wrapper-22">Completed (<span class="count-completed">1</span>)</div></div>
            </div>
            <div class="task-list">
              <div class="card-5" data-status="in-progress">
                <div class="task-list-2">
                  <img class="container-14" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/container-3.svg" />
                  <div class="container-15">
                    <div class="div-2">
                      <div class="card-title-2"><div class="text-wrapper-23">Review Recursion Concepts</div></div>
                      <div class="badge-2 status-badge"><div class="text-wrapper-24">In Progress</div></div>
                      <div class="high-priority-wrapper"><div class="text-wrapper-25">High Priority</div></div>
                    </div>
                    <div class="progress-bar-container">
                      <div class="progress-bar-wrapper">
                        <div class="progress-bar" data-progress="65"></div>
                      </div>
                      <div class="progress-text">65% Complete</div>
                    </div>
                    <div class="div-wrapper-3"><div class="text-wrapper-21">Data Structures &amp; Algorithms</div></div>
                  </div>
                </div>
                <div class="card-content">
                  <div class="div-wrapper-2">
                    <p class="text-wrapper-26">Go through lecture notes and practice problems on recursion</p>
                  </div>
                  <div class="task-list-3">
                    <div class="container-16">
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-5.svg" />
                      <div class="text-3"><div class="text-wrapper-27">Due: 11/24/2025</div></div>
                    </div>
                    <div class="container-17">
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-7.svg" />
                      <div class="text"><div class="text-wrapper-28">18:00</div></div>
                    </div>
                  </div>
                  <div class="task-list-4">
                    <button class="button-9">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-13.svg" />
                      <div class="text-wrapper-29">View Details</div>
                    </button>
                    <div class="primitive-button-5 status-dropdown">
                      <div class="primitive-span"><div class="text-wrapper-30 status-text">In Progress</div></div>
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-1.svg" />
                      <div class="status-menu">
                        <div class="status-option" data-status="todo">To Do</div>
                        <div class="status-option" data-status="in-progress">In Progress</div>
                        <div class="status-option" data-status="completed">Completed</div>
                      </div>
                    </div>
                    <div class="container-18"></div>
                    <button class="button-10 edit-btn">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-12.svg" />
                      <div class="text-wrapper-31">Edit</div>
                    </button>
                    <button class="button-11 delete-btn">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-4.svg" />
                      <div class="text-wrapper-32">Delete</div>
                    </button>
                  </div>
                </div>
              </div>
              <div class="card-5" data-status="todo">
                <div class="task-list-2">
                  <img class="container-14" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/container-5.svg" />
                  <div class="container-15">
                    <div class="div-2">
                      <div class="card-title-2"><div class="text-wrapper-33">Complete CSS Grid Tutorial</div></div>
                      <div class="badge-3 status-badge"><div class="text-wrapper-25">To Do</div></div>
                      <div class="medium-priority-wrapper"><div class="text-wrapper-25">Medium Priority</div></div>
                    </div>
                    <div class="div-wrapper-3"><div class="text-wrapper-21">Web Development 101</div></div>
                  </div>
                </div>
                <div class="card-content">
                  <div class="div-wrapper-2">
                    <p class="text-wrapper-26">Finish the responsive design tutorial using CSS Grid</p>
                  </div>
                  <div class="task-list-3">
                    <div class="container-16">
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-5.svg" />
                      <div class="text-3"><div class="text-wrapper-27">Due: 11/26/2025</div></div>
                    </div>
                    <div class="container-17">
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-7.svg" />
                      <div class="text"><div class="text-wrapper-28">20:00</div></div>
                    </div>
                  </div>
                  <div class="task-list-4">
                    <button class="button-9">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-13.svg" />
                      <div class="text-wrapper-29">View Details</div>
                    </button>
                    <div class="primitive-button-5 status-dropdown">
                      <div class="primitive-span-2"><div class="text-wrapper-30 status-text">To Do</div></div>
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-1.svg" />
                      <div class="status-menu">
                        <div class="status-option" data-status="todo">To Do</div>
                        <div class="status-option" data-status="in-progress">In Progress</div>
                        <div class="status-option" data-status="completed">Completed</div>
                      </div>
                    </div>
                    <div class="container-18"></div>
                    <button class="button-10 edit-btn">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-12.svg" />
                      <div class="text-wrapper-31">Edit</div>
                    </button>
                    <button class="button-11 delete-btn">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-4.svg" />
                      <div class="text-wrapper-32">Delete</div>
                    </button>
                  </div>
                </div>
              </div>
              <div class="card-5" data-status="completed">
                <div class="task-list-2">
                  <img class="container-14" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/container-6.svg" />
                  <div class="container-15">
                    <div class="div-2">
                      <div class="card-title-3">
                        <p class="text-wrapper-34">Read Chapter 5: Database Normalization</p>
                      </div>
                      <div class="badge-4 status-badge"><div class="text-wrapper-24">Completed</div></div>
                      <div class="badge-5"><div class="text-wrapper-25">Medium Priority</div></div>
                    </div>
                    <div class="div-wrapper-3"><div class="text-wrapper-21">Database Management</div></div>
                  </div>
                </div>
                <div class="card-content">
                  <div class="div-wrapper-2">
                    <p class="text-wrapper-26">Read and summarize chapter 5 from the textbook</p>
                  </div>
                  <div class="task-list-3">
                    <div class="container-16">
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-5.svg" />
                      <div class="text-3"><div class="text-wrapper-27">Due: 11/21/2025</div></div>
                    </div>
                    <div class="container-17">
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-7.svg" />
                      <div class="text"><div class="text-wrapper-28">16:00</div></div>
                    </div>
                  </div>
                  <div class="task-list-4">
                    <button class="button-9">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-13.svg" />
                      <div class="text-wrapper-29">View Details</div>
                    </button>
                    <div class="primitive-button-5 status-dropdown">
                      <div class="primitive-span-3"><div class="text-wrapper-30 status-text">Completed</div></div>
                      <img class="icon" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-1.svg" />
                      <div class="status-menu">
                        <div class="status-option" data-status="todo">To Do</div>
                        <div class="status-option" data-status="in-progress">In Progress</div>
                        <div class="status-option" data-status="completed">Completed</div>
                      </div>
                    </div>
                    <div class="container-18"></div>
                    <button class="button-10 edit-btn">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-12.svg" />
                      <div class="text-wrapper-31">Edit</div>
                    </button>
                    <button class="button-11 delete-btn">
                      <img class="icon-3" src="https://c.animaapp.com/mil8vcnf2JGZLn/img/icon-4.svg" />
                      <div class="text-wrapper-32">Delete</div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
