// Mobile Menu Toggle
const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const navMenu = document.querySelector('.nav-menu');

if (mobileMenuToggle) {
  mobileMenuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('mobile-open');
    
    // Animate hamburger icon
    const spans = mobileMenuToggle.querySelectorAll('span');
    if (navMenu.classList.contains('mobile-open')) {
      spans[0].style.transform = 'rotate(45deg) translateY(8px)';
      spans[1].style.opacity = '0';
      spans[2].style.transform = 'rotate(-45deg) translateY(-8px)';
    } else {
      spans[0].style.transform = 'none';
      spans[1].style.opacity = '1';
      spans[2].style.transform = 'none';
    }
  });
}

// Close mobile menu when clicking outside
document.addEventListener('click', (e) => {
  if (navMenu.classList.contains('mobile-open') && 
      !navMenu.contains(e.target) && 
      !mobileMenuToggle.contains(e.target)) {
    navMenu.classList.remove('mobile-open');
    const spans = mobileMenuToggle.querySelectorAll('span');
    spans[0].style.transform = 'none';
    spans[1].style.opacity = '1';
    spans[2].style.transform = 'none';
  }
});

// Tab Switching Functionality
const tabs = document.querySelectorAll('.tab');
const notificationItems = document.querySelectorAll('.notification-item');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    // Remove active class from all tabs
    tabs.forEach(t => t.classList.remove('active'));
    
    // Add active class to clicked tab
    tab.classList.add('active');
    
    // Get selected category
    const category = tab.dataset.tab;
    
    // Filter notifications
    notificationItems.forEach(item => {
      if (category === 'all') {
        item.classList.remove('hidden');
      } else {
        if (item.dataset.category === category) {
          item.classList.remove('hidden');
        } else {
          item.classList.add('hidden');
        }
      }
    });
    
    // Update unread count
    updateUnreadCount();
  });
});

// Mark All as Read Functionality
const markAllReadBtn = document.querySelector('.mark-all-read-btn');
const unreadBadge = document.querySelector('.unread-badge');

if (markAllReadBtn) {
  markAllReadBtn.addEventListener('click', () => {
    // Remove unread class from all notifications
    notificationItems.forEach(item => {
      item.classList.remove('unread');
      
      // Remove "New" badges
      const newBadge = item.querySelector('.new-badge');
      if (newBadge) {
        newBadge.remove();
      }
    });
    
    // Update unread count
    updateUnreadCount();
    
    // Show feedback
    showFeedback('All notifications marked as read');
  });
}

// Mark Individual Notification as Read
notificationItems.forEach(item => {
  item.addEventListener('click', () => {
    if (item.classList.contains('unread')) {
      item.classList.remove('unread');
      
      // Remove "New" badge
      const newBadge = item.querySelector('.new-badge');
      if (newBadge) {
        newBadge.remove();
      }
      
      // Update unread count
      updateUnreadCount();
    }
  });
});

// Update Unread Count
function updateUnreadCount() {
  const activeTab = document.querySelector('.tab.active');
  const category = activeTab.dataset.tab;
  
  let unreadCount = 0;
  
  notificationItems.forEach(item => {
    if (item.classList.contains('unread') && !item.classList.contains('hidden')) {
      unreadCount++;
    }
  });
  
  // Update header badge
  if (unreadBadge) {
    if (unreadCount > 0) {
      unreadBadge.textContent = `${unreadCount} Unread`;
      unreadBadge.style.display = 'inline-block';
    } else {
      unreadBadge.style.display = 'none';
    }
  }
  
  // Update navbar badge
  const navBadge = document.querySelector('.nav-item.active .badge');
  if (navBadge) {
    const totalUnread = document.querySelectorAll('.notification-item.unread').length;
    if (totalUnread > 0) {
      navBadge.textContent = totalUnread;
      navBadge.style.display = 'inline-block';
    } else {
      navBadge.style.display = 'none';
    }
  }
  
  // Update tab badges
  updateTabBadges();
}

// Update Tab Badges
function updateTabBadges() {
  tabs.forEach(tab => {
    const category = tab.dataset.tab;
    const badge = tab.querySelector('.tab-badge');
    
    if (category === 'all') {
      const totalUnread = document.querySelectorAll('.notification-item.unread').length;
      if (badge && totalUnread > 0) {
        badge.textContent = totalUnread;
      }
    } else {
      let categoryUnread = 0;
      notificationItems.forEach(item => {
        if (item.dataset.category === category && item.classList.contains('unread')) {
          categoryUnread++;
        }
      });
      
      if (badge) {
        if (categoryUnread > 0) {
          badge.textContent = categoryUnread;
          badge.style.display = 'inline-block';
        } else {
          badge.style.display = 'none';
        }
      }
    }
  });
}

// Show Feedback Message
function showFeedback(message) {
  // Create feedback element
  const feedback = document.createElement('div');
  feedback.textContent = message;
  feedback.style.cssText = `
    position: fixed;
    bottom: 24px;
    right: 24px;
    background-color: #101727;
    color: white;
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 14px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 1000;
    animation: slideIn 0.3s ease-out;
  `;
  
  // Add animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateY(100%);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
    @keyframes slideOut {
      from {
        transform: translateY(0);
        opacity: 1;
      }
      to {
        transform: translateY(100%);
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(feedback);
  
  // Remove after 3 seconds
  setTimeout(() => {
    feedback.style.animation = 'slideOut 0.3s ease-out';
    setTimeout(() => {
      feedback.remove();
    }, 300);
  }, 3000);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  updateUnreadCount();
});
