<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <title>EduFlow Hub - Notifications</title>
  <link rel="stylesheet" href="globals.css" />
  <link rel="stylesheet" href="notif.css" />
</head>
<body>
  <div class="app">
    <!-- Sticky Top Navbar -->
    <nav class="top-navbar">
      <div class="navbar-container">
        <!-- Logo Section -->
        <div class="logo-section">
          <div class="logo-icon">
            <div class="logo-image"></div>
          </div>
          <div class="logo-text">
            <h1 class="logo-title">EduFlow Hub</h1>
            <p class="logo-subtitle">Smart Learning Flow</p>
          </div>
        </div>

        <!-- Navigation Menu -->
        <div class="nav-menu">
          <a class="nav-item" href="dashboard.php">
            <img class="nav-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/icon-3.svg" alt="Dashboard" />
            <span>Dashboard</span>
          </a>
          <a class="nav-item" href="classes.php">
            <img class="nav-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/icon.svg" alt="Classes" />
            <span>Classes</span>
          </a>
          <a class="nav-item" href="ass.php">
            <img class="nav-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/icon-6.svg" alt="Assignments" />
            <span>Assignments</span>
          </a>
          <a class="nav-item" href="study.php">
            <img class="nav-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/icon-2.svg" alt="Study Planner" />
            <span>Study Planner</span>
          </a>
          <a class="nav-item" href="mess.php">
            <img class="nav-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/icon-1.svg" alt="Messages" />
            <span>Messages</span>
          </a>
          <a class="nav-item active" href="notif.php">
            <img class="nav-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/icon-5.svg" alt="Notifications" />
            <span>Notifications</span>
            <span class="badge">3</span>
          </a>
        </div>

        <!-- User Profile -->
        <div class="user-section">
          <a class="notification-bell" href="settings.php">
            <img src="https://c.animaapp.com/mil9v3vyHCDnga/img/button.svg" alt="Notifications" />
          </a>
          <a class="user-profile" href="profile.php">
            <div class="user-avatar">
              <span>KG</span>
            </div>
            <div class="user-info">
              <p class="user-name">Khert Galarde</p>
              <p class="user-role">Student</p>
            </div>
          </a>
        </div>

        <!-- Mobile Menu Toggle -->
        <button class="mobile-menu-toggle" aria-label="Toggle menu">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
      <div class="content-container">
        <!-- Page Header -->
        <header class="page-header">
          <div class="header-text">
            <h2 class="page-title">Notifications</h2>
            <p class="page-description">Stay updated with your academic activities.</p>
          </div>
          <div class="header-actions">
            <span class="unread-badge">3 Unread</span>
            <button class="mark-all-read-btn">
              <img src="https://c.animaapp.com/mil9v3vyHCDnga/img/icon-4.svg" alt="" />
              <span>Mark All as Read</span>
            </button>
          </div>
        </header>

        <!-- Notifications Card -->
        <div class="notifications-card">
          <div class="card-header">
            <h3 class="card-title">All Notifications</h3>
            <p class="card-description">View and manage your notifications by category</p>
          </div>

          <!-- Tabs -->
          <div class="tabs-container">
            <div class="tab-list" role="tablist">
              <button class="tab active" data-tab="all" role="tab">
                <span>All</span>
                <span class="tab-badge">3</span>
              </button>
              <button class="tab" data-tab="announcements" role="tab">
                <span>Announcements</span>
              </button>
              <button class="tab" data-tab="assignments" role="tab">
                <span>Assignments</span>
                <span class="tab-badge">1</span>
              </button>
              <button class="tab" data-tab="grades" role="tab">
                <span>Grades</span>
                <span class="tab-badge">1</span>
              </button>
              <button class="tab" data-tab="deadlines" role="tab">
                <span>Deadlines</span>
                <span class="tab-badge">1</span>
              </button>
              <button class="tab" data-tab="system" role="tab">
                <span>System</span>
              </button>
            </div>
          </div>

          <!-- Notification List -->
          <div class="notification-list">
            <!-- Notification Item 1 -->
            <div class="notification-item unread" data-category="assignments">
              <img class="notification-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/container-4.svg" alt="" />
              <div class="notification-content">
                <div class="notification-header">
                  <p class="notification-title">New assignment uploaded for Web Development 101</p>
                  <span class="new-badge">New</span>
                </div>
                <p class="notification-description">Activity 3: Responsive Web Design has been posted</p>
                <p class="notification-time">30 minutes ago</p>
              </div>
            </div>

            <!-- Notification Item 2 -->
            <div class="notification-item unread" data-category="grades">
              <img class="notification-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/container-5.svg" alt="" />
              <div class="notification-content">
                <div class="notification-header">
                  <p class="notification-title">Grade updated: Research Paper – 92%</p>
                  <span class="new-badge">New</span>
                </div>
                <p class="notification-description">Your research paper has been graded</p>
                <p class="notification-time">2 hours ago</p>
              </div>
            </div>

            <!-- Notification Item 3 -->
            <div class="notification-item" data-category="deadlines">
              <img class="notification-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/container-2.svg" alt="" />
              <div class="notification-content">
                <div class="notification-header">
                  <p class="notification-title">Upcoming quiz tomorrow in Data Structures</p>
                </div>
                <p class="notification-description">Topics: Trees, Graphs, and Algorithms</p>
                <p class="notification-time">5 hours ago</p>
              </div>
            </div>

            <!-- Notification Item 4 -->
            <div class="notification-item" data-category="announcements">
              <img class="notification-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/container-2.svg" alt="" />
              <div class="notification-content">
                <div class="notification-header">
                  <p class="notification-title">Instructor posted an announcement in Humanities</p>
                </div>
                <p class="notification-description">Class will be held online via Zoom</p>
                <p class="notification-time">1 day ago</p>
              </div>
            </div>

            <!-- Notification Item 5 -->
            <div class="notification-item unread" data-category="deadlines">
              <img class="notification-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/container-1.svg" alt="" />
              <div class="notification-content">
                <div class="notification-header">
                  <p class="notification-title">Submission deadline reminder: Project Proposal – 2 days left</p>
                  <span class="new-badge">New</span>
                </div>
                <p class="notification-description">Don't forget to submit your project proposal</p>
                <p class="notification-time">1 day ago</p>
              </div>
            </div>

            <!-- Notification Item 6 -->
            <div class="notification-item" data-category="grades">
              <img class="notification-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/container-5.svg" alt="" />
              <div class="notification-content">
                <div class="notification-header">
                  <p class="notification-title">Quiz 2 grade posted: 95%</p>
                </div>
                <p class="notification-description">Excellent work on Data Structures quiz</p>
                <p class="notification-time">2 days ago</p>
              </div>
            </div>

            <!-- Notification Item 7 -->
            <div class="notification-item" data-category="system">
              <img class="notification-icon" src="https://c.animaapp.com/mil9v3vyHCDnga/img/container.svg" alt="" />
              <div class="notification-content">
                <div class="notification-header">
                  <p class="notification-title">System maintenance scheduled</p>
                </div>
                <p class="notification-description">Platform will be down for 2 hours on Nov 20</p>
                <p class="notification-time">3 days ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>

  <script src="notif.js"></script>
</body>
</html>
