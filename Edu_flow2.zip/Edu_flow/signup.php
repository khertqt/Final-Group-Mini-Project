<?php
$conn = new mysqli("localhost", "root", "", "edu_flow");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $first_name = trim($_POST['first_name']);
    $last_name  = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $student_id = trim($_POST['student_id']);
    $phone      = trim($_POST['phone']);
    $program    = $_POST['program'];
    $year_level = $_POST['year_level'];
    $password   = $_POST['password'];
    $agree      = isset($_POST['agree']) ? 1 : 0;

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $check = $conn->prepare("SELECT id FROM users WHERE email=? OR student_id=?");
    $check->bind_param("ss", $email, $student_id);
    $check->execute();
    $check->store_result();
    if ($stmt->execute()) {
        $message = "Account created successfully! Redirecting to login...";
        $message_type = "success";
        echo "<script>
                setTimeout(function(){
                    window.location.href = 'login.php';
                }, 2000);
              </script>";
    } else {
        $message = "Something went wrong.";
        $message_type = "error";
    }

    $stmt->close();
    $check->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="signup.css" />
  </head>
  <script>
  const notif = document.getElementById("successNotif");
  if (notif && notif.textContent.trim() !== "") {
    notif.classList.add("show");
  }
</script>



  <body>
    <div class="signup" data-model-id="14:519">
      <div class="container">
        <div class="div">
          <div class="container-2">
            <div class="image-eduflow-hub-wrapper"><div class="image-eduflow-hub"></div></div>
            <div class="container-3">
              <div class="heading"><div class="text-wrapper">EduFlow Hub</div></div>
              <div class="div-2"><p class="p">Powered by Smart Learning Flow</p></div>
            </div>
          </div>
          <div class="container-4">
            <div class="div-3"><div class="text-wrapper-2">Join Our Community!</div></div>
            <div class="paragraph">
              <p class="create-your-account">
                Create your account and start managing your academic journey with ease. Get instant access to your
                classes, assignments, and academic progress.
              </p>
            </div>
          </div>
          <div class="container-5">
            <div class="container-6">
              <img class="img" src="https://c.animaapp.com/bQaNppAc/img/container.svg" />
              <div class="container-7">
                <div class="div-2"><div class="text-wrapper-3">Centralized Dashboard</div></div>
                <div class="div-wrapper"><p class="text-wrapper-4">All your academic information in one place</p></div>
              </div>
            </div>
            <div class="container-6">
              <img class="img" src="https://c.animaapp.com/bQaNppAc/img/container-1.svg" />
              <div class="container-8">
                <div class="div-2"><div class="text-wrapper-3">Real-time Updates</div></div>
                <div class="div-wrapper">
                  <p class="get-notified-about">Get notified about grades, assignments, and announcements</p>
                </div>
              </div>
            </div>
            <div class="container-6">
              <img class="img" src="https://c.animaapp.com/bQaNppAc/img/container-2.svg" />
              <div class="container-9">
                <div class="div-2"><div class="text-wrapper-3">Easy Communication</div></div>
                <div class="div-wrapper">
                  <p class="text-wrapper-5">Connect with instructors and classmates instantly</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header">
            <div class="card-title"><div class="text-wrapper-6">Create Account</div></div>
            <div class="card-description"><p class="text-wrapper-7">Fill in your details to get started</p></div>
          </div>
          <div class="div-4">
            <div class="container-10">
              <div class="container-11">
                <div class="primitive-label"><div class="text-wrapper-8">First Name</div></div>
                <div class="div-3">
                  <input class="input" placeholder="Name" type="Name" id="input-1" />
                  <img class="icon" src="https://c.animaapp.com/bQaNppAc/img/icon.svg" />
                </div>
              </div>
              <div class="container-12">
                <div class="primitive-label"><div class="text-wrapper-8">Last Name</div></div>
                <div class="div-3">
                  <input class="input" placeholder="Last Name" type="LName" id="input-1" />
                  <img class="icon" src="https://c.animaapp.com/bQaNppAc/img/icon-1.svg" />
                </div>
              </div>
            </div>
            <div class="container-13">
              <div class="primitive-label"><label class="text-wrapper-8" for="input-1">Email Address</label></div>
              <div class="div-3">
                <input class="input" placeholder="your.email@school.edu" type="email" id="input-1" />
                <img class="icon-2" src="https://c.animaapp.com/bQaNppAc/img/icon-2.svg" />
              </div>
            </div>
            <div class="container-14">
              <div class="container-11">
                <div class="primitive-label"><div class="text-wrapper-8">Student ID</div></div>
                <input class="input" placeholder="2023303810" type="ID" id="input-1" />
              </div>
              <div class="container-12">
                <div class="primitive-label"><div class="text-wrapper-8">Phone</div></div>
                <div class="div-3">
                  <input class="input" placeholder="+69 975 686 1301" type="PhoneNumber" id="input-1" />
                  <img class="icon" src="https://c.animaapp.com/bQaNppAc/img/icon-3.svg" />
                </div>
              </div>
            </div>
            <div class="container-15">
            <div class="container-11">
                <div class="primitive-label">
                <div class="text-wrapper-8">Program</div>
                </div>

                <select class="select-dropdown">
                <option value="" disabled selected>Select program</option>
                <option value="BSIT">BS Information Technology</option>
                <option value="BSCS">BS Computer Science</option>
                <option value="BSE">BS Engineering</option>
                <option value="BSA">BS Accountancy</option>
                <option value="BSBA">BS Business Administration</option>
                </select>
            </div>

            <div class="container-12">
                <div class="primitive-label">
                <div class="text-wrapper-8">Year Level</div>
                </div>

                <select class="select-dropdown">
                <option value="" disabled selected>Select year</option>
                <option value="1">1st Year</option>
                <option value="2">2nd Year</option>
                <option value="3">3rd Year</option>
                <option value="4">4th Year</option>
                </select>
            </div>
            </div>
            <div class="container-13">
            <div class="primitive-label"><div class="text-wrapper-8">Password</div></div>
            <div class="div-3">
                <input class="input password-field" placeholder="Create a strong password" type="password" />
                <img class="icon-2" src="https://c.animaapp.com/bQaNppAc/img/icon-7.svg" />
                <img class="button toggle-password"
                    src="https://c.animaapp.com/80cXYxUU/img/button.svg"
                    style="cursor:pointer;" />
            </div>
            </div>


    <div class="container-13">
    <div class="primitive-label"><div class="text-wrapper-8">Confirm Password</div></div>
    <div class="div-3">
        <input class="input password-field" placeholder="Confirm your password" type="password" />
        <img class="icon-2" src="https://c.animaapp.com/bQaNppAc/img/icon-7.svg" />
        <img class="button toggle-password"
            src="https://c.animaapp.com/80cXYxUU/img/button.svg"
            style="cursor:pointer;" />
    </div>
    </div>



            <div class="container-16">
            <label class="checkbox-wrapper">
                <input type="checkbox" id="agree" />
                <span class="primitive-button-2"></span>

                <div class="label">
                <div class="text-wrapper-11">I agree to the</div>
                <div class="link"><div class="text-wrapper-12">Terms and Conditions</div></div>
                <div class="text-wrapper-13">and</div>
                <div class="link-2"><div class="text-wrapper-14">Privacy Policy</div></div>
                </div>
            </label>
            </div>

            <button class="create-btn" id="createAccountBtn">Create Account</button>
            <!-- Notification -->
            <div class="success-notification" id="successNotif">
            <?php if (!empty($message)): ?>
                <p class="<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </p>
            <?php endif; ?>
            </div>


            <div class="container-17">
              <div class="text"></div>
              <div class="or-sign-up-with-wrapper"><div class="or-sign-up-with">OR SIGN UP WITH</div></div>
            </div>
            <div class="container-18">
              <button class="button-3">
                <img class="img-2" src="https://c.animaapp.com/bQaNppAc/img/signup.svg" />
                <div class="text-wrapper-16">Google</div>
              </button>
              <button class="button-4">
                <img class="img-3" src="https://c.animaapp.com/bQaNppAc/img/signup-1.svg" />
                <div class="text-wrapper-17">Facebook</div>
              </button>
            </div>
            <div class="div-2">
            <div class="text-wrapper-18">Already have an account?</div>

            <a href="login.php" style="text-decoration: none;">
                <button class="button-5">
                <div class="text-wrapper-19">Sign in</div>
                </button>
            </a>
            </div>

        </div>
      </div>
    </div>
  </body>
</html>
