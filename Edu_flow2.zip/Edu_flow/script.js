// Modal functionality
const modals = {
  submitAssignment: document.getElementById('submitAssignmentModal'),
  checkGrades: document.getElementById('checkGradesModal'),
  contactInstructor: document.getElementById('contactInstructorModal')
};

const buttons = {
  submitAssignment: document.getElementById('submitAssignmentBtn'),
  checkGrades: document.getElementById('checkGradesBtn'),
  contactInstructor: document.getElementById('contactInstructorBtn')
};

// Open modal function
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

// Close modal function
function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  }
}

// Show toast notification
function showToast(message) {
  const toast = document.getElementById('successToast');
  const toastMessage = toast.querySelector('.toast-message');
  toastMessage.textContent = message;
  toast.classList.add('active');
  
  setTimeout(() => {
    toast.classList.remove('active');
  }, 3000);
}

// Event listeners for opening modals
buttons.submitAssignment.addEventListener('click', () => {
  openModal('submitAssignmentModal');
});

buttons.checkGrades.addEventListener('click', () => {
  openModal('checkGradesModal');
});

buttons.contactInstructor.addEventListener('click', () => {
  openModal('contactInstructorModal');
});

// Event listeners for closing modals
document.querySelectorAll('.close-btn').forEach(btn => {
  btn.addEventListener('click', (e) => {
    const modalId = e.target.getAttribute('data-modal');
    closeModal(modalId);
  });
});

document.querySelectorAll('.btn-secondary').forEach(btn => {
  btn.addEventListener('click', (e) => {
    const modalId = e.target.getAttribute('data-modal');
    if (modalId) {
      closeModal(modalId);
    }
  });
});

// Close modal when clicking outside
Object.values(modals).forEach(modal => {
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeModal(modal.id);
    }
  });
});

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    Object.keys(modals).forEach(key => {
      closeModal(modals[key].id);
    });
  }
});

// Form submissions
document.getElementById('submitAssignmentForm').addEventListener('submit', (e) => {
  e.preventDefault();
  
  const className = document.getElementById('assignmentClass').selectedOptions[0].text;
  const title = document.getElementById('assignmentTitle').value;
  const file = document.getElementById('assignmentFile').files[0];
  
  // Simulate submission
  setTimeout(() => {
    closeModal('submitAssignmentModal');
    showToast(`Assignment "${title}" submitted successfully for ${className}!`);
    
    // Reset form
    e.target.reset();
  }, 500);
});

document.getElementById('contactInstructorForm').addEventListener('submit', (e) => {
  e.preventDefault();
  
  const instructor = document.getElementById('instructorSelect').selectedOptions[0].text;
  const subject = document.getElementById('messageSubject').value;
  
  // Simulate sending message
  setTimeout(() => {
    closeModal('contactInstructorModal');
    showToast(`Message sent to ${instructor.split(' - ')[0]} successfully!`);
    
    // Reset form
    e.target.reset();
  }, 500);
});

// View Classes button (just for demo)
document.querySelector('.button-8').addEventListener('click', () => {
  showToast('Navigating to Classes page...');
});
