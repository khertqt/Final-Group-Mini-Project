<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="dashboard.css" />
    <script src="script.js" defer></script>
  </head>
  <body>
    <div class="dashboard">
      <div class="top-navbar">
        <div class="container">
          <div class="div">
            <div class="image-eduflow-hub-wrapper"><div class="image-eduflow-hub"></div></div>
            <div class="container-2">
              <div class="heading"><div class="text-wrapper">EduFlow Hub</div></div>
              <div class="div-wrapper"><div class="text-wrapper-2">Smart Learning Flow</div></div>
            </div>
          </div>
          <div class="container-3">
            <a class="button">
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-9.svg" />
              <div class="text"><div class="text-wrapper-3">Dashboard</div></div>
            </a>
            <a button class="button-2" href="classes.php">
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-7.svg" />
              <div class="text"><div class="text-wrapper-4">Classes</div></div>
            </a>
            <a button class="button-3" href="ass.php">
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-2.svg" />
              <div class="text"><div class="text-wrapper-5">Assignments</div></div>
            </a>
            <a button class="button-4" href="study.php"> 
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon.svg" />
              <div class="text"><div class="text-wrapper-6">Study Planner</div></div>
            </a>
            <a button class="button-5" href="mess.php">
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-1.svg" />
              <div class="text"><div class="text-wrapper-7">Messages</div></div>
            </a>
            <a div class="button-6" href="notif.php">
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-5.svg" />
              <div class="text"><div class="text-wrapper-8">Notifications</div></div>
              <div class="badge"><div class="text-wrapper-9">3</div></div>
            </a>
          </div>
          <div class="container-4">
            <a href="settings.php">
              <img class="img" src="https://c.animaapp.com/mil7h04rRDwqbl/img/button.svg" />
            </a>
            <a div class="button-7" href="profile.php">
              <div class="container-5">
                <div class="text-2"><div class="text-wrapper-10">KG</div></div>
              </div>
              <div class="container-6">
                <div class="paragraph"><div class="text-wrapper-11">Khert Galarde</div></div>
                <div class="div-wrapper"><div class="text-wrapper-12">Student</div></div>
              </div>
            </a>
          </div>
        </div>
      </div>
      <div class="div-2">
        <div class="container-7">
          <div class="heading-2"><div class="text-wrapper-13">Welcome back, Khert!</div></div>
          <div class="here-s-what-s-wrapper">
            <p class="here-s-what-s">Here's what's happening with your classes today.</p>
          </div>
        </div>
        <div class="container-8">
          <div class="card">
            <div class="card-header">
              <div class="card-title"><div class="today-s-classes">Today's Classes</div></div>
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-12.svg" />
            </div>
            <div class="card-content">
              <div class="div-wrapper-2"><div class="text-wrapper-14">3</div></div>
              <div class="div-wrapper"><div class="text-wrapper-12">Scheduled for today</div></div>
            </div>
          </div>
          <div class="card-2">
            <div class="card-header">
              <div class="card-title-2"><div class="text-wrapper-15">Pending Assignments</div></div>
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-2.svg" />
            </div>
            <div class="card-content">
              <div class="div-wrapper-2"><div class="text-wrapper-14">5</div></div>
              <div class="div-wrapper"><div class="text-wrapper-12">Due this week</div></div>
            </div>
          </div>
          <div class="card-3">
            <div class="card-header">
              <div class="card-title-3"><div class="text-wrapper-16">Enrolled Classes</div></div>
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-10.svg" />
            </div>
            <div class="card-content">
              <div class="div-wrapper-2"><div class="text-wrapper-14">5</div></div>
              <div class="div-wrapper"><div class="text-wrapper-12">Active courses</div></div>
            </div>
          </div>
          <div class="card-4">
            <div class="card-header">
              <div class="card-title-4"><div class="text-wrapper-17">Average Grade</div></div>
              <img class="icon" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-8.svg" />
            </div>
            <div class="card-content">
              <div class="div-wrapper-2"><div class="text-wrapper-14">91.5%</div></div>
              <div class="div-wrapper"><div class="text-wrapper-18">+2.5% from last term</div></div>
            </div>
          </div>
        </div>
        <div class="container-9">
          <div class="card">
            <div class="card-header-2">
              <div class="card-title-5"><div class="text-wrapper-19">Today's Classes</div></div>
              <div class="card-description"><div class="text-wrapper-20">Your schedule for today</div></div>
            </div>
            <div class="card-content-2">
              <div class="div-3">
                <img class="container-10" src="https://c.animaapp.com/mil7h04rRDwqbl/img/container.svg" />
                <div class="container-11">
                  <div class="paragraph"><div class="text-wrapper-21">Web Development 101</div></div>
                  <div class="div-wrapper"><p class="text-wrapper-12">9:00 AM - 10:30 AM</p></div>
                  <div class="container-12">
                    <div class="badge-2"><div class="text-wrapper-22">Room 304</div></div>
                    <div class="text-3"><div class="text-wrapper-23">Prof. Santos</div></div>
                  </div>
                </div>
              </div>
              <div class="div-3">
                <img class="container-10" src="https://c.animaapp.com/mil7h04rRDwqbl/img/container.svg" />
                <div class="container-11">
                  <div class="paragraph"><div class="text-wrapper-21">Data Structures &amp; Algorithms</div></div>
                  <div class="div-wrapper"><p class="text-wrapper-12">1:00 PM - 2:30 PM</p></div>
                  <div class="container-12">
                    <div class="badge-3"><div class="text-wrapper-22">Online</div></div>
                    <div class="text-4"><div class="text-wrapper-24">Prof. Reyes</div></div>
                  </div>
                </div>
              </div>
              <div class="div-3">
                <img class="container-10" src="https://c.animaapp.com/mil7h04rRDwqbl/img/container.svg" />
                <div class="container-11">
                  <div class="paragraph"><div class="text-wrapper-21">Database Management</div></div>
                  <div class="div-wrapper"><p class="text-wrapper-12">3:00 PM - 4:30 PM</p></div>
                  <div class="container-12">
                    <div class="badge-4"><div class="text-wrapper-25">Lab 201</div></div>
                    <div class="text-5"><div class="text-wrapper-26">Prof. Garcia</div></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-2">
            <div class="card-header-2">
              <div class="card-title-5"><div class="text-wrapper-19">Pending Assignments</div></div>
              <div class="card-description"><div class="text-wrapper-20">Upcoming deadlines</div></div>
            </div>
            <div class="card-content-2">
              <div class="div-3">
                <img class="container-10" src="https://c.animaapp.com/mil7h04rRDwqbl/img/container-2.svg" />
                <div class="container-13">
                  <div class="paragraph-2"><div class="text-wrapper-21">HTML Page Design</div></div>
                  <div class="paragraph-3"><div class="text-wrapper-12">Web Development 101</div></div>
                  <div class="badge-5"><div class="text-wrapper-27">Due: Nov 25, 2025</div></div>
                </div>
              </div>
              <div class="div-3">
                <img class="container-10" src="https://c.animaapp.com/mil7h04rRDwqbl/img/container-2.svg" />
                <div class="container-13">
                  <div class="paragraph-2"><div class="text-wrapper-21">Research Paper Draft</div></div>
                  <div class="paragraph-3"><div class="text-wrapper-12">Humanities</div></div>
                  <div class="badge-5"><div class="text-wrapper-27">Due: Nov 30, 2025</div></div>
                </div>
              </div>
              <div class="div-3">
                <img class="container-10" src="https://c.animaapp.com/mil7h04rRDwqbl/img/container-1.svg" />
                <div class="container-13">
                  <div class="paragraph-2"><div class="text-wrapper-21">Database Normalization Task</div></div>
                  <div class="paragraph-3"><div class="text-wrapper-12">Database Management</div></div>
                  <div class="badge-6"><div class="text-wrapper-28">Due: Nov 18, 2025</div></div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-5">
            <div class="card-header-2">
              <div class="card-title-5"><div class="text-wrapper-19">Recent Grades</div></div>
              <div class="card-description"><div class="text-wrapper-20">Your latest scores</div></div>
            </div>
            <div class="card-content-3">
              <div class="div-4">
                <div class="container-14">
                  <div class="paragraph"><div class="text-wrapper-21">Quiz 2: Recursion</div></div>
                  <div class="div-wrapper"><div class="text-wrapper-12">Data Structures</div></div>
                </div>
                <div class="paragraph-4"><div class="text-wrapper-29">95%</div></div>
              </div>
              <div class="div-4">
                <div class="container-14">
                  <div class="paragraph"><div class="text-wrapper-21">Research Paper</div></div>
                  <div class="div-wrapper"><div class="text-wrapper-12">Humanities</div></div>
                </div>
                <div class="paragraph-4"><div class="text-wrapper-29">92%</div></div>
              </div>
              <div class="div-4">
                <div class="container-14">
                  <div class="paragraph"><div class="text-wrapper-21">Midterm Exam</div></div>
                  <div class="div-wrapper"><div class="text-wrapper-12">Web Development</div></div>
                </div>
                <div class="paragraph-4"><div class="text-wrapper-29">88%</div></div>
              </div>
            </div>
          </div>
          <div class="card-6">
            <div class="card-header-2">
              <div class="card-title-5"><div class="text-wrapper-19">Announcements</div></div>
              <div class="card-description"><div class="text-wrapper-20">Latest updates from instructors</div></div>
            </div>
            <div class="card-content-2">
              <div class="div-5">
                <div class="paragraph"><p class="text-wrapper-21">Class on Friday will be asynchronous</p></div>
                <div class="container-15">
                  <div class="paragraph-5"><div class="text-wrapper-30">Data Structures</div></div>
                  <div class="paragraph-6"><div class="text-wrapper-31">2 hours ago</div></div>
                </div>
              </div>
              <div class="div-5">
                <div class="paragraph"><div class="text-wrapper-21">New learning materials uploaded</div></div>
                <div class="container-15">
                  <div class="paragraph-7"><div class="text-wrapper-32">Web Development</div></div>
                  <div class="paragraph-6"><div class="text-wrapper-31">5 hours ago</div></div>
                </div>
              </div>
              <div class="div-5">
                <div class="paragraph"><p class="text-wrapper-21">Quiz scheduled for next week</p></div>
                <div class="container-15">
                  <div class="paragraph-8"><div class="text-wrapper-33">Database Management</div></div>
                  <div class="paragraph-9"><div class="text-wrapper-34">1 day ago</div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-7">
          <div class="card-title-6"><div class="text-wrapper-19">Quick Actions</div></div>
          <div class="div-6">
            <button class="button-8"><div class="text-wrapper-35">View Classes</div></button>
            <button class="button-9" id="submitAssignmentBtn">
              <img class="icon-2" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-3.svg" />
              <div class="text-wrapper-36">Submit Assignment</div>
            </button>
            <button class="button-10" id="checkGradesBtn">
              <img class="icon-2" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-6.svg" />
              <div class="text-wrapper-37">Check Grades</div>
            </button>
            <button class="button-11" id="contactInstructorBtn">
              <img class="icon-2" src="https://c.animaapp.com/mil7h04rRDwqbl/img/icon-4.svg" />
              <div class="text-wrapper-38">Contact Instructor</div>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Submit Assignment Modal -->
    <div id="submitAssignmentModal" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <h2>Submit Assignment</h2>
          <button class="close-btn" data-modal="submitAssignmentModal">&times;</button>
        </div>
        <form id="submitAssignmentForm" class="modal-form">
          <div class="form-group">
            <label for="assignmentClass">Select Class</label>
            <select id="assignmentClass" required>
              <option value="">Choose a class...</option>
              <option value="web-dev">Web Development 101</option>
              <option value="data-structures">Data Structures & Algorithms</option>
              <option value="database">Database Management</option>
              <option value="humanities">Humanities</option>
            </select>
          </div>
          <div class="form-group">
            <label for="assignmentTitle">Assignment Title</label>
            <input type="text" id="assignmentTitle" placeholder="Enter assignment title" required />
          </div>
          <div class="form-group">
            <label for="assignmentFile">Upload File</label>
            <input type="file" id="assignmentFile" accept=".pdf,.doc,.docx,.zip" required />
          </div>
          <div class="form-group">
            <label for="assignmentNotes">Additional Notes (Optional)</label>
            <textarea id="assignmentNotes" rows="4" placeholder="Add any comments or notes..."></textarea>
          </div>
          <div class="modal-actions">
            <button type="button" class="btn-secondary" data-modal="submitAssignmentModal">Cancel</button>
            <button type="submit" class="btn-primary">Submit Assignment</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Check Grades Modal -->
    <div id="checkGradesModal" class="modal">
      <div class="modal-content modal-large">
        <div class="modal-header">
          <h2>Your Grades</h2>
          <button class="close-btn" data-modal="checkGradesModal">&times;</button>
        </div>
        <div class="grades-container">
          <div class="grade-summary">
            <div class="summary-card">
              <div class="summary-label">Overall GPA</div>
              <div class="summary-value">3.65</div>
            </div>
            <div class="summary-card">
              <div class="summary-label">Current Term</div>
              <div class="summary-value">3.82</div>
            </div>
            <div class="summary-card">
              <div class="summary-label">Credits Earned</div>
              <div class="summary-value">45</div>
            </div>
          </div>
          <div class="grades-list">
            <div class="grade-item">
              <div class="grade-info">
                <div class="grade-class">Web Development 101</div>
                <div class="grade-details">Prof. Santos • 3 Credits</div>
              </div>
              <div class="grade-score grade-a">A</div>
            </div>
            <div class="grade-item">
              <div class="grade-info">
                <div class="grade-class">Data Structures & Algorithms</div>
                <div class="grade-details">Prof. Reyes • 4 Credits</div>
              </div>
              <div class="grade-score grade-a">A-</div>
            </div>
            <div class="grade-item">
              <div class="grade-info">
                <div class="grade-class">Database Management</div>
                <div class="grade-details">Prof. Garcia • 3 Credits</div>
              </div>
              <div class="grade-score grade-b">B+</div>
            </div>
            <div class="grade-item">
              <div class="grade-info">
                <div class="grade-class">Humanities</div>
                <div class="grade-details">Prof. Martinez • 3 Credits</div>
              </div>
              <div class="grade-score grade-a">A</div>
            </div>
            <div class="grade-item">
              <div class="grade-info">
                <div class="grade-class">Computer Networks</div>
                <div class="grade-details">Prof. Lee • 3 Credits</div>
              </div>
              <div class="grade-score grade-b">B</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Contact Instructor Modal -->
    <div id="contactInstructorModal" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <h2>Contact Instructor</h2>
          <button class="close-btn" data-modal="contactInstructorModal">&times;</button>
        </div>
        <form id="contactInstructorForm" class="modal-form">
          <div class="form-group">
            <label for="instructorSelect">Select Instructor</label>
            <select id="instructorSelect" required>
              <option value="">Choose an instructor...</option>
              <option value="santos">Prof. Santos - Web Development 101</option>
              <option value="reyes">Prof. Reyes - Data Structures & Algorithms</option>
              <option value="garcia">Prof. Garcia - Database Management</option>
              <option value="martinez">Prof. Martinez - Humanities</option>
            </select>
          </div>
          <div class="form-group">
            <label for="messageSubject">Subject</label>
            <input type="text" id="messageSubject" placeholder="Enter subject" required />
          </div>
          <div class="form-group">
            <label for="messageBody">Message</label>
            <textarea id="messageBody" rows="6" placeholder="Type your message here..." required></textarea>
          </div>
          <div class="form-group">
            <label>
              <input type="checkbox" id="urgentMessage" />
              Mark as urgent
            </label>
          </div>
          <div class="modal-actions">
            <button type="button" class="btn-secondary" data-modal="contactInstructorModal">Cancel</button>
            <button type="submit" class="btn-primary">Send Message</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Success Toast -->
    <div id="successToast" class="toast">
      <div class="toast-content">
        <span class="toast-icon">✓</span>
        <span class="toast-message"></span>
      </div>
    </div>
  </body>
</html>
